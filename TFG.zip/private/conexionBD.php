<?php
    function conectarBaseDatos(){
        // Creamos la conexión a nuestra BD
        $db_server = "localhost";
        $db_username = "root";
        $db_password = "";
        $db_name = "waywolf";

        try {
            $conn = new PDO("mysql:host=$db_server;dbname=$db_name", $db_username, $db_password);
            // Configurar el modo de error de PDO a excepción
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        } catch(PDOException $e) {
            echo "Error en la conexión: " . $e->getMessage();
            die();
        }
    }
?>