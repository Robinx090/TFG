<?php include("cabecera.php") ?>
<?php 
    session_start(); 

    // En el caso de que haya un error en la sesión, guardaremos dicha variable y la mostramos
    $error = "";
    if (isset($_SESSION['error'])) {
        $error = $_SESSION['error'];
        unset($_SESSION['error']); // Una vez guardado el mensaje de error, se borrará la session error
    }
?>

<main>
    <?php
        // Obtenemos el valor de la variable 'tipo' desde la URL
        $tipo = $_GET['tipo'];

        switch($tipo){
            case "logout":
                // Iniciamos la session y eliminamos todo tipo de sesiones y las destruimos
                session_unset();
                session_destroy();
                header("Location: forms.php?tipo=login"); // Redirige al usuario a la página de inicio de sesión
                exit();
                break;

            case "login":

                // Verificamos si el usuario está logueado
                if (isset($_SESSION['user'])) {
                    $usuario = $_SESSION['user'];

                    // Ahora verificamos si el mensaje de bienvenida a sido mostrado
                    if (!isset($_SESSION['bienvenida'])) {
                        // Establecer la sesión para indicar que el mensaje ya ha sido mostrado
                        $_SESSION['bienvenida'] = true;
                        $mostrarBienvenida = true;
                    } else {
                        $mostrarBienvenida = false;
                    }
                }
            ?>
            <!-- En el caso de que haya un mensaje de bienvenida, ocultamos el formulario y mostramos otra interfaz -->
            <?php if (isset($mostrarBienvenida)): ?>
                <h1 id="bienvenida">Bienvenido, <?php echo htmlspecialchars($usuario); ?>!</h1>
                <style> .containForm{display: none;} </style>

                <div class="container mt-4">
                    <div class="row text-end">
                        <div class="col"> <a href="forms.php?tipo=logout" class="btn btn-link">Cerrar sesión</a> </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-md-12 custom-col text-center">
                            <h2>Rutina completada</h2>
                            <div class="calendar-header d-flex justify-content-around">
                                <div>L</div><div>M</div><div>X</div><div>J</div><div>V</div><div>S</div><div>D</div>
                            </div>
                            <div id="calendar" class="calendar"></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
                <div class="containForm">
                    <form id="login" method="post" action="function/envioForms.php?estado=login">
                        <h1 class="text-center">Iniciar sesión</h1><br>
                        
                        <!-- Nombre de Usuario -->
                        <label for="usuario">Usuario</label>
                        <input type="text" name="usuarioLogin" id="usuario" placeholder="Johnny">

                        <!-- Contraseña -->
                        <label for="pass">Contraseña</label>
                        <input type="password" name="passLogin" id="pass" placeholder="**********"><br>

                        <strong><span class="text-danger-emphasis errores"> <?php echo $error ?> </span></strong>

                        <!-- Botón de Enviar, antes de enviar tendremos que validarlo con la BASE DE DATOS-->
                        <div class="text-center mt-3">
                            <input type="submit" value="Entrar" id="enviar">
                        </div>

                        <!-- En el caso de que no tenga cuenta -->
                        <div class="text-center mt-3">
                            <a href="forms.php?tipo=register" class="text-dark"><u>¿Aún no tienes cuenta?</u></a><br>
                            <a href="forms.php?tipo=olvido" class="text-dark"><u>¿Has olvidado tu contraseña?</u></a>
                        </div>
                    </form> 
                </div>
    <?php
                break;

            case "register":
                ?>
                <div class="containForm">
                    <form id="register" method="post" action="function/envioForms.php?estado=registro">
                        <h1 class="text-center">Registrarse</h1><br>

                        <!-- Usuario -->
                        <label for="usuario">Usuario</label>
                        <input type="text" name="usuarioRegister" id="usuario" placeholder="Johnny">
                        
                        <!-- Contraseña -->
                        <label for="pass">Contraseña</label>
                        <input type="password" name="passRegister" id="pass" placeholder="**********">

                        <!-- Email del usuario  -->
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" placeholder="john@gmail.com"><br>

                        <label for="preguntaSeguridad">¿Cuál es el apodo que tenías de pequeño?</label>
                        <input type="text" name="preguntaSeguridad" id="preguntaSeguridad" placeholder="juanito">

                        <strong><span class="text-danger-emphasis errores"> 
                            <?php 
                                $mensaje = "";
                                // En el caso de que haya una session con el nombre de usuario existente se dará el mensaje de error
                                if(isset($_SESSION['usuarioExiste'])){
                                    $mensaje = $_SESSION['usuarioExiste'];
                                    echo $mensaje;
                                    unset($_SESSION['usuarioExiste']); // Una vez hemos guardado el mensaje, mataremos la session
                                } ?>
                        </span></strong>

                        <!-- Botón de Enviar, antes de enviar tendremos que validarlo con la BASE DE DATOS-->
                        <div class="text-center mt-3">
                            <input type="submit" value="Registrarse"><br>
                            <!-- En el caso de que ya tenga cuenta -->
                            <a href="forms.php?tipo=login" class="text-center text-dark mt-3"><u>¿Ya tienes una cuenta?</u></a>
                        </div>
                    </form> 
                </div>
                <?php
                break;

            case "olvido":
                ?>
                <div class="containForm">
                    <form id="olvidar" method="post" action= "function/envioForms.php?estado=olvido">
                        <h1 class="text-center">Olvidé mi contraseña</h1><br>
                        
                        <!-- EMAIL  -->
                        <label for="email">Pon el email con el que te registraste:</label>
                        <input type="email" name="email" id="email" placeholder="John@gmail.com">
                        
                        <label for="preguntaSeguridad">¿Cuál es el apodo que tenías de pequeño?</label>
                        <input type="text" name="preguntaSeguridad" id="preguntaSeguridad" placeholder="pregunta de seguridad">

                        <strong><span class="text-danger-emphasis errores"> <?php echo $error; ?> </span></strong>

                        <!-- Botón de Enviar, antes de enviar tendremos que validarlo con la BASE DE DATOS-->
                        <div class="text-center">
                            <input type="submit" value="Olvidé la contraseña">
                        </div>

                        <!-- En el caso de que ya tenga cuenta -->
                        <div class="text-center">
                            <a href="forms.php?tipo=login" class="text-dark"><u>Volver</u></a>
                        </div>
                    </form> 
                </div>
                <?php
                break;
            
            case "resetPass":
                // En el caso de que no tenga esta session significará que está intentando entrar a la fuerza
                if($_SESSION['canReset'] !== true ){
                    // En el caso de que no se encuentre ninguna session, lo devolveremos al login directamente
                    header("Location: forms.php?tipo=login");
                    exit();
                }
                ?>
                <div class="containForm">
                    <form id="resetPass" method="post" action= "function/envioForms.php?estado=resetPass">
                        <h1 class="text-center">Restablece tú contraseña</h1><br>
                        
                        <!-- Contraseña nueva  -->
                        <label for="newPass">Nueva contraseña:</label>
                        <input type="password" name="newPass" id="newPass" placeholder="********">

                        <strong><span class="text-danger-emphasis errores"> </span></strong>

                        <!-- Botón de Enviar, antes de enviar tendremos que validarlo con la BASE DE DATOS-->
                        <div class="text-center">
                            <input type="submit" value="Cambiar contraseña">
                        </div>

                        <!-- En el caso de que ya tenga cuenta -->
                        <div class="text-center">
                            <a href="forms.php?tipo=login" class="text-dark"><u>Volver</u></a>
                        </div>
                    </form> 
                </div>
                <?php
                break;

            case "calCalorias":
                ?>
                <div class="containForm">
                    <form method="post" id="calCalorias">
                        <h1 class="text-center">Calculadora de Calorías</h1><br>
                        
                        <!-- Edad -->
                        <label for="edad">Edad</label>
                        <input type="number" name="edad" id="edad" value="25" required>

                        <!-- Peso -->
                        <label for="peso">Peso (kg)</label>
                        <input type="number" name="peso" id="peso" value="60" required>

                        <!-- Sexo -->
                        <label class="mt-3">Género</label><br>
                        <input type="radio" name="sexo" id="hombre" value="hombre">
                        <label for="hombre">Hombre</label>
                        <input type="radio" name="sexo" id="mujer" value="mujer" checked>
                        <label for="mujer" class="mb-3">Mujer</label><br>

                        <!-- Estatura -->
                        <label for="estatura">Estatura (cm)</label>
                        <input type="number" name="estatura" id="estatura" value="180" required>

                        <!-- Actividad -->
                        <label for="actividad">Actividad Física</label>
                        <select name="actividad" id="actividad">
                            <option value="sedentario">Poco o nada de ejercicio</option>
                            <option value="ligero">Poco ejercicio de 1 a 3 días a la semana</option>
                            <option value="moderado">Promedio de 3 a 5 días de ejercicio</option>
                            <option value="activo">Mucho ejercicio de 6 a 7 días a la semana</option>
                            <option value="muyActivo">Muy pesado, ejercicio dos veces a la semana</option>
                        </select><br><br>

                        <div id="caloriasMantenerPeso">Calorias Diarias Necesarias Para Mantener Su Peso: <br>
                            <strong><span id="mantenerPeso" class="fs-1 text-dark">2482</span></strong>
                        </div>
                        <div id="caloriasPerderUnaLibra">Calorias Diarias Necesarias Para Perder 0.5 kl a la semana: <br>
                            <strong><span id="perderUnaLibra" class="fs-1 text-dark">1982</span></strong>
                        </div>
                        <div id="caloriasPerderDosLibras">Calorias Diarias Necesarias Para Perder 1 Kl a la semana: <strong><br>
                            <span id="perderDosLibras" class="fs-1 text-dark">1482</span></strong>
                        </div>

                    </form> 
                </div>
                <?php
                break;
            
            case "calIMC":
                ?>
                <div class="containForm">
                    <form method="post" id="calIMC">
                    <!-- TODO: Cambiar estas variables y ponerlo en un css externo -->
                    <style>
                        .text-dark {
                            color: black;
                        }
                        .text-yellow {
                            color: yellow;
                        }
                        .text-green {
                            color: darkgreen;
                        }
                        .text-red {
                            color: red;
                        }
                        .highlight {
                            font-weight: bold;
                        }
                    </style>
                        <h1 class="text-center">Calculadora de IMC</h1><br>
                        
                        <!-- Peso -->
                        <label for="peso">Peso (kg)</label>
                        <input type="number" name="peso" id="peso" value="70" required>

                        <!-- Altura -->
                        <label for="altura">Altura (cm)</label>
                        <input type="number" name="altura" id="altura" value="170" required>

                        <!-- Elemento para mostrar el IMC y su categoría -->
                        <p>Su índice de masa corporal es:</p> 
                        <strong><span id="imcValor" class="fs-1 text-dark">24.7</span></strong>
                        
                        <p class="mt-5">
                            <span id="catMuyBajoPeso1">0-15: Muy bajo peso</span> <br>
                            <span id="catMuyBajoPeso2">15-16: Muy bajo peso</span> <br>
                            <span id="catBajoPeso">16-18.5: Bajo peso</span> <br>
                            <span id="catNormal">18.5 - 25: Rango Normal (saludable)</span><br>
                            <span id="catSobrepeso">25-30: Sobrepeso</span><br>
                            <span id="catObeso1">30 - 35: Clase obesa I - Obesa moderada</span><br>
                            <span id="catObeso2">35 - 40: Clase obesa II - Muy obesa</span><br>
                            <span id="catObeso3">40+: Obeso clase III - Muy obesos</span>
                        </p>
                    </form>
                </div>
                <?php
                break;
            
            case "calProteina":
                ?>
                <div class="containForm">
                    <form method="post" id="calProteinas">
                    <h1 class="text-center">Calculadora de Proteínas</h1><br>
            
                    <!-- Peso -->
                    <label for="peso">Peso (kg)</label>
                    <input type="number" name="peso" id="peso" value="70" required><br>

                    <!-- Nivel de actividad -->
                    <label>Nivel de Actividad</label><br>
                    <input type="radio" name="nivelActividad" id="bajoEntrenamiento" value="bajoEntrenamiento" checked>
                    <label for="bajoEntrenamiento">Nivel bajo de entrenamiento</label><br>
                    <input type="radio" name="nivelActividad" id="resistencia" value="resistencia">
                    <label for="resistencia">Entrenamiento de resistencia</label><br>
                    <input type="radio" name="nivelActividad" id="fuerza" value="fuerza">
                    <label for="fuerza">Entrenamiento de fuerza</label><br><br>

                    <!-- Checkbox para vegetariano -->
                    <input type="checkbox" name="vegetariano" id="vegetariano">
                    <label for="vegetariano">¿Eres vegetariano?</label><br><br>

                    <!-- Proteína al día -->
                    <div id="proteinaResultado">Proteína al día recomendada: <br>
                        <strong class="fs-1 text-dark"><span id="proteinaValor">55.4</span> gramos</strong>
                    </div>
                    </form> 
                </div>
                <?php
                break;
            case "rutinas";
                // Ahora comprobaremos si el usuario consiguió entrar o no, viendo si tiene alguna session
                if($_SESSION['conectado'] !== true ){
                    // En el caso de que no se encuentre ninguna session, lo devolveremos al login directamente
                    header("Location: forms.php?tipo=login");
                    exit();
                }

                // Verificamos si el usuario está logueado
                if (isset($_SESSION['user'])) {
                    $usuario = $_SESSION['user'];

                    // Ahora verificamos si el mensaje de bienvenida a sido mostrado
                    if (!isset($_SESSION['bienvenida'])) {
                        // Establecer la sesión para indicar que el mensaje ya ha sido mostrado
                        $_SESSION['bienvenida'] = true;
                        $mostrarBienvenida = true;
                    } else {
                        $mostrarBienvenida = false;
                    }
                }
            ?>
                <style> .hidden{display: none;} </style>

                <?php if (isset($mostrarBienvenida)): ?>
                    <h1 id="bienvenida">Bienvenido, <?php echo htmlspecialchars($usuario); ?>!</h1>
                    <script>
                        // Ocultamos cuándo pasen los 5 segundos
                        setTimeout(function() { document.getElementById('bienvenida').classList.add('hidden'); }, 5000);
                    </script>
                <?php endif;

                    // Accedemos a la carpeta privada para conectarse a la base de datos
                    require("../../private/conexionBD.php");
                    require("function/funcionalidadesBD.php");
                    $conexion = conectarBaseDatos();

                    // Recuperamos el id del usuario
                    if(isset($_SESSION['user'])){
                        $id_usuario= id_usuario($conexion, $_SESSION['user'], "usuarios");
                        $_SESSION['id_usuario'] = $id_usuario;
                        if(!isset($id_usuario)){
                            echo "No se a encontrado ninguna rutina";
                        }
                    }

                    $se_hace_dieta = false;
                    $rutina = [];
                    $mensajeObjetivo = "";
                    // Comprobaremos si se a establecido el id usuario y si existe una rutina
                    if(tieneRutina($conexion, $id_usuario)){
                        // En el caso de que tenga haremos una consulta para acceder a los ejercicios y la dieta
                        $ids = obtenerIDs($conexion, $id_usuario);
                        // En el caso de que el id dieta sea 0, significará que el usuario ha dicho que no quiere dieta
                        if($ids['dieta']){
                            $se_hace_dieta = true;
                        }

                        // Una vez obtenido los ids de ejercicios y dieta se guardan en una variable
                        $rutina = accederRutina($conexion, $id_usuario, $ids['ejercicios'], $ids['dieta']);

                        // Ahora guardamos el mensaje según el objetivo tendrá uno u otro
                        $mensajeObjetivo = obtenerMensajeObjetivo($conexion, $id_usuario);
                    
                ?>
                    <!-- Ocultamos el formulario de creación de rutinas -->
                    <style> .containForm{display: none;} </style>

                    <!-- Contenedor de la tabla de rutinas -->
                    <div class="container">
                        <p class="fs-5 text-center"> <?=$mensajeObjetivo  ?> </p>

                        <!-- Tenemos un contenedor el cuál contendrá los 2 botones con los que el usuario podrá generar una nueva rutina o eliminar dicha rutina -->
                        <div class="d-flex justify-content-between mb-3">
                            <form method="post" action="function/envioForms.php?estado=rutina0">
                                <button type="submit" name="accionRutina" class="button bg-secondary"> Crear rutina de 0 </button>
                            </form>
                        </div>

                        <!-- Tabla de Rutina de Ejercicios -->
                        <div class="row">
                            <div class="col">
                                <h2 class="text-center bg-secondary">Rutina de Ejercicios</h2>
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead class="text-center">
                                            <tr>
                                                <th style="background-color:lightgray; border: 2px solid black;"></th>
                                                <th style="background-color:lightgray; border: 2px solid black;">Ejercicio</th>
                                                <th style="background-color:lightgray; border: 2px solid black;">Técnica</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if(isset($rutina)){
                                                    $dia = 1;
                                                    foreach ($rutina['ejercicios'] as $index => $ejercicio) {
                                                        // Comenzar una nueva fila cada 15 ejercicios (3 días * 5 ejercicios por día)
                                                        if ($index % 3 == 0) {
                                                            if ($index != 0) {
                                                                echo "</tr>"; // Cerrar la fila anterior antes de comenzar una nueva
                                                            }
                                                            ?>
                                                            <tr>
                                                                <td style="vertical-align: middle; text-align: center; border: 2px solid black; background-color:lightgray;" rowspan="3"><strong> <?=$dia?>º Rutina </strong></td>
                                                                <?php
                                                                $dia++;
                                                        } else {
                                                            echo "<tr>";
                                                        }
                                                        ?>
                                                        <td><?php echo $ejercicio['ejercicios']; ?></td>
                                                        <td><a href="<?php echo $ejercicio['url']; ?>" target="_blank">Técnica de <?php echo $ejercicio['ejercicios']; ?></a></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                    // Cerrar la última fila si es necesario
                                                    if (count($rutina['ejercicios']) % 3 != 0) {
                                                        echo "</tr>";
                                                    }
                                                }                                                                                                
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <?php
                            if($se_hace_dieta == true){
                        ?>

                        <!-- Tenemos un contenedor el cuál contendrá los 2 botones con los que el usuario podrá generar una nueva dieta o eliminarla -->
                        
                        <form method="post" action="function/envioForms.php?estado=otraDieta">
                            <button type="submit" name="crearDieta" class="button bg-secondary" > Crear otra dieta </button>
                        </form>
                        
                        <!-- Tabla de Dieta -->
                        <div class="container">
                            <p class="fs-5 text-center"> Puedes calcular tus porciones calóricas necesarias <a href="./forms.php?tipo=calCalorias"> aquí </a> </p>
                            <!-- Tabla de Dieta para ordenadores -->
                            <div class="row mt-4 d-none d-md-table m-auto">
                                <div class="col">
                                    <h2 class="text-center bg-secondary">Dieta</h2>
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                            <thead class="text-center">
                                                <tr>
                                                    <th style="background-color:lightgray; border: 2px solid black;">Día</th>
                                                    <th style="background-color:lightgray; border: 2px solid black;">Desayuno</th>
                                                    <th style="background-color:lightgray; border: 2px solid black;">Almuerzo</th>
                                                    <th style="background-color:lightgray; border: 2px solid black;">Cena</th>
                                                    <th style="background-color:lightgray; border: 2px solid black;">Snacks</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $dia = 1;
                                                foreach ($rutina['dieta'] as $dieta):
                                                    ?>
                                                    <tr>
                                                        <td style="background-color:lightgray; border: 2px solid black;"><strong><?php echo $dia; ?></strong></td>
                                                        <td><?php echo $dieta['desayuno']; ?></td>
                                                        <td><?php echo $dieta['almuerzo']; ?></td>
                                                        <td><?php echo $dieta['cena']; ?></td>
                                                        <td><?php echo $dieta['snacks']; ?></td>
                                                    </tr>
                                                    <?php
                                                    $dia++;
                                                endforeach;
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- Tabla de Dieta para móviles -->
                            <div class="row mt-4 d-md-none">
                                <div class="col">
                                    <h2 class="text-center bg-secondary">Dieta</h2>
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                        <?php
                                            $dia = 1; // Inicializamos el día a partir de 1
                                            foreach ($rutina['dieta'] as $dieta):
                                                if (!empty($dieta['desayuno'])) {
                                                    ?>
                                                    <thead class="text-center">
                                                        <tr>
                                                            <th style="background-color:lightgray; border: 2px solid black;" colspan="2">Día <?php echo $dia; ?></th> <!-- Colspan para que ocupe dos columnas -->
                                                        </tr>
                                                    </thead>                                                    
                                                    <tr>
                                                        <th>Desayuno</th>
                                                        <td><?php echo $dieta['desayuno']; ?></td>
                                                    </tr>
                                                    <?php
                                                }
                                                if (!empty($dieta['almuerzo'])) {
                                                    ?>
                                                    <tr>
                                                        <th>Almuerzo</th>
                                                        <td><?php echo $dieta['almuerzo']; ?></td>
                                                    </tr>
                                                    <?php
                                                }
                                                if (!empty($dieta['cena'])) {
                                                    ?>
                                                    <tr>
                                                        <th>Cena</th>
                                                        <td><?php echo $dieta['cena']; ?></td>
                                                    </tr>
                                                    <?php
                                                }
                                                if (!empty($dieta['snacks'])) {
                                                    ?>
                                                    <tr>
                                                        <th>Snacks</th>
                                                        <td><?php echo $dieta['snacks']; ?></td>
                                                    </tr>
                                                    <?php
                                                }
                                                $dia ++;
                                            endforeach;
                                            ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                        }
                    ?>
                <?php
                    }else{
                ?>
                        <!-- Formulario para la creación de la rutina -->
                        <div class="containForm">
                            <form id="rutinas" method="post" action="function/envioForms.php?estado=rutinas">
                                <h1 class="text-center">Crea tu rutina</h1><br>
                                
                                <!-- OBJETIVO -->
                                <label for="objetivo">Objetivo:</label><br>
                                <select id="objetivo" name="objetivo">
                                    <option value="perder_peso">Perder peso</option>
                                    <option value="ganar_musculo">Ganar músculo</option>
                                    <option value="aumentar_resistencia">Aumentar resistencia</option>
                                </select><br><br>
                                
                                <!-- NIVEL -->
                                <label>Nivel:</label><br>
                                <input type="radio" id="principiante" name="nivel" value="principiante">
                                <label for="principiante">Principiante</label><br>

                                <input type="radio" id="intermedio" name="nivel" value="intermedio">
                                <label for="intermedio">Intermedio</label><br>

                                <input type="radio" id="avanzado" name="nivel" value="avanzado">
                                <label for="avanzado">Avanzado</label><br><br>
                                
                                <!-- PESAS -->
                                <label for="maquinaria">¿Dispones de maquinaria?</label><br>
                                <input type="radio" id="si_maquinaria" name="maquinaria" value="si">
                                <label for="si_maquinaria">Sí</label><br>
                                <input type="radio" id="no_maquinaria" name="maquinaria" value="no">
                                <label for="no_maquinaria">No</label><br><br>

                                <strong><span class="text-danger-emphasis errores"> </span></strong>

                                <div class="text-center">
                                    <input type="submit" value="Crear Rutina">
                                </div>
                            </form> 
                        </div>
                <?php
                    }
                ?>
                <?php
                break;
        }
    ?>
</main>
<?php include("footer.php") ?>