<footer class="pie-pagina">
    <div class="grupo1">
        <!-- LOGO -->
        <div class="box">
            <figure>
                <a href="index.php"> <img src="./img/icon/logo.jpeg" alt="logo"> </a>
            </figure>
        </div>
        
        <!-- PÁGINAS -->
        <div class="box">
            <div class ="paginas">
                <a href="forms.php?tipo=login">Inicia Sesión</a>
                <a href="forms.php?tipo=rutinas">Rutinas</a>
                <a href="forms.php?tipo=calCalorias">Calculadora Calorías</a>
                <a href="forms.php?tipo=calIMC">Calculadora IMC (Índice Masa Muscular)</a>
                <a href="forms.php?tipo=calProteina">Calculadora Proteínas</a>
            </div>
        </div>

        <!-- REDES SOCIALES -->
        <div class="box">
            <h2>Síguenos</h2>
            <div class="redes-sociales">
                <a href="#"> <i class="bi bi-facebook"></i> </a>
                <a href="#"> <i class="bi bi-instagram"></i> </a>
                <a href="#"> <i class="bi bi-twitter-x"></i> </a>
            </div>
        </div>
    </div>

    <!-- COPYRIGHT -->
    <div class="grupo2">
        <small>© 2023 <b>WayWolf</b> - Todos los Derechos Reservados</small>
    </div>
</footer>
</body>
</html>
