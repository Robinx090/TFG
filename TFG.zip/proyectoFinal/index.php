<!-- BARRA DE NAVEGACIÓN -->
<?php include("cabecera.php"); ?>

<!-- El contenido de la página principal -->
<main class="main">
    <!-- Carrusel con animaciones -->
    <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
        <img src="./img/carrusel/organiza_tuTiempo.jpg" alt="organiza tu tiempo" class="img-fluid" style="max-height: 700px;">
        <div class="textOrganiza">
            <h1>¿No tienes tiempo de organizarte?</h1>
            <h3>Tranquilo, te creamos la rutina en 5 minutos</h3>
            <a href="forms.php?tipo=rutinas" class="button">Crea tú rutina</a>
        </div>
    </div>

    <!-- Haz tú rutina en cuestión de 5 minutos -->
    <div class="container mt-5">
        <div class="row contenedor d-flex align-items-center">
            <div class="col-md-6 ">
                <h3 class="encabezado mt-5">Haz tu rutina con nosotros</h3>
                <p class="text">
                    ¿Quieres alcanzar tus objetivos de fitness de forma rápida, fácil y totalmente personalizada? ¡Entonces estás en el lugar adecuado! Con nuestra plataforma, puedes crear tu propia rutina de entrenamiento en tan solo 5 minutos, ¡sin ningún costo!
                    Con solo unos pocos clics, podrás personalizar tu rutina de entrenamiento y comenzar a ver resultados tangibles en poco tiempo. ¡Ya no hay excusas para no ponerse en forma! Únete a nuestra comunidad hoy mismo y descubre cómo puedes transformar tu vida de manera rápida y sencilla
                </p>
                <div class="text-center">
                    <!-- TODO: En el caso de que ya esté iniciado sesión que le envíe directo a crear la rutina -->
                    <!-- TODO: En el caso de que no esté iniciado sesión que le lleve a loguearse -->
                    <a href="forms.php?tipo=rutinas" class="button">¡Empieza hoy mismo!</a>
                </div>
            </div>
            <div class="col-md-6">
                <img src="./img/principales/tiempo.avif" class="img-fluid mt-3 mb-3" alt="Tu rutina en 5 minutos" style="max-width: 100%;">
            </div>
        </div>
    </div>

    <!-- Contenedor de las tarjetas de información -->
    <div class="container mt-5 d-flex flex-column justify-content-center">
        <h2 class="mt-5 mb-5 text-center bg-white p-2" style="color: darkred;">¿Sobre qué quieres aprender?</h2>
        <!-- La 1º fila de las 3 columnas -->
        <div class="row">
            <!-- Cargamos los parámetros de la función loadCard -->
            <?php
                include "function/plantillas.php";

                loadCard("./img/tarjetas/adelgazar.avif", "adelgazar",
                    "Pérdida de grasa", 
                    "Descubre los secretos para perder grasa de forma efectiva y mantener un estilo de vida saludable", "infoCard.php?titulo=adelgazar");
                
                loadCard("./img/tarjetas/aumento.avif", "aumento muscular",
                    "Aumento muscular", 
                    "Aprende las mejores técnicas y estrategias para ganar músculo y alcanzar tu máximo potencial físico.", "infoCard.php?titulo=aumento");
                
                loadCard("./img/tarjetas/descanso.avif", "buen descanso",
                    "Sueño y descanso", 
                    "Descubre la importancia del sueño y el descanso en tu salud y bienestar general.", "infoCard.php?titulo=descanso");
            ?>
        </div>

        <!-- Las 2º fila de 3 columnas -->
        <div class="row">
            <?php
            // Cargamos los parámetros de la función loadCard
                loadCard("./img/tarjetas/dejar_de_Fumar.jpg", "Dejar de fumar",
                    "Métodos Probados Para Dejar de Fumar Rápidamente", 
                    "Todos sabemos que decir adiós a los cigarrillos es como terminar una relación tóxica. Sabemos que no es buena para nosotros, pero...",
                    "infoCard.php?titulo=dejar_de_Fumar");
                
                loadCard("./img/tarjetas/flaco_musculoso.jpg", "flaco_musculoso",
                    "Por qué algunos flacos superan en fuerza a los musculosos", 
                    "Cuando piensas en alguien fuerte, probablemente te imagines un cuerpo cubierto de músculos voluminosos. Sin embargo,",
                    "infoCard.php?titulo=flacoMusculoso");
                
                loadCard("./img/tarjetas/addiccion.jpg", "Adicción al tik tok",
                    "¿Te hace Tik Tok más Tonto? El vínculo entre el contenido corto y el deterioro cognitivo", 
                    "Tik Tok, la plataforma de origen chino que ha conquistado a millones de usuarios",
                    "infoCard.php?titulo=adiccion");
            ?>
        </div>

        <!-- Las 3º fila de 3 columnas -->
        <div class="row">
            <?php
                loadCard("./img/tarjetas/noFap.jpg", "noFAP",
                    "NOFAP: Cómo la abstinencia sexual puede transformar tu vida", 
                    "La búsqueda del bienestar y la mejora personal es un viaje constante y, en ese camino, muchas personas se encuentran con el movimiento NOFAP.",
                    "infoCard.php?titulo=noFAP");
                
                loadCard("./img/tarjetas/testosterona.jpg", "testosterona",
                    "Aumentar naturalmente la Testosterona - La guía completa", 
                    "La testosterona, esa palabra que resuena con fuerza cuando hablamos de masculinidad, es mucho más que...", "infoCard.php?titulo=testosterona");
                
                loadCard("./img/tarjetas/crecimientoMuscular.jpg", "crecimiento muscular",
                    "¿Existen los límites naturales del crecimiento muscular?", 
                    "El músculo es un tejido fascinante y complejo, capaz de adaptarse y cambiar en función de las demandas que le imponemos. El crecimiento...",
                    "infoCard.php?titulo=crecimiento_muscular");
            ?>
        </div>

        <!-- Las 4º fila de 3 columnas -->
        <div class="row">

            <?php
                loadCard("./img/tarjetas/gimnasio.jpg", "gimnasio",
                    "Máquinas de gimnasio frente a pesos libres: El VS definitivo", 
                    "Cuando se trata de lograr nuestros objetivos de fitness, la elección del equipo adecuado es",
                    "infoCard.php?titulo=maq_vs_pesas");
                            
                loadCard("./img/tarjetas/rostro.jpg", "rostro",
                    "Adelgazar la Cara: Reducir Mejillas y Eliminar Papada", 
                    "En nuestra sociedad actual, la belleza y la apariencia física tienen un gran peso en cómo nos percibimos.",
                    "infoCard.php?titulo=rostro");
                
                loadCard("./img/tarjetas/bebidas_energeticas.jpg", "bebidas_energeticas",
                    "Los efectos para la salud de las bebidas energéticas", 
                    "Las bebidas energéticas han ganado una popularidad asombrosa en todo el mundo, prometiendo mejorar...",
                    "infoCard.php?titulo=bebidas_energeticas");
            ?>
        </div>
    </div>
</main>

<!-- PIE DE PÁGINA -->
<?php include("footer.php") ?>