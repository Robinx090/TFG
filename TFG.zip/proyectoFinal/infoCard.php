<?php include("cabecera.php") ?>
<main>
    <?php

        // Incluimos el archivo dónde tenemos los métodos que contienen las plantillas
        include "function/plantillas.php";

        // Obtenemos el valor de la variable 'tipo' desde la URL
        $titulo = $_GET['titulo'];

        // Switch basado en el titulo
        switch ($titulo) {
            case "adelgazar":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                    ['src' => "./img/infoCard/adelgazar/sonrisa.avif", 'alt' => 'Sonrisa'],
                    ['src' => "./img/infoCard/adelgazar/feliz.avif", 'alt' => 'feliz'],
                    ['src' => "./img/infoCard/adelgazar/habitos.avif", 'alt' => 'habitos'],
                ];

                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Adelgazar", // title
                    "Perder peso no se trata solo de estética, sino que es un paso fundamental para mejorar tu salud y bienestar general. Al eliminar el exceso de grasa corporal, reduces el riesgo de padecer enfermedades crónicas, aumentas tu energía y vitalidad, y mejoras tu autoestima e imagen personal.", // description
                    "<strong style='background-color: lightgray; color: black;'>Adopta hábitos alimenticios saludables:</strong> Elige alimentos nutritivos y ricos en fibra, como frutas, verduras y granos integrales. Limita el consumo de alimentos procesados, azucarados y ricos en grasas saturadas y trans.
                    <br><br><strong style='background-color: lightgray; color: black;'>Controla el tamaño de las porciones:</strong> Presta atención al tamaño de las porciones y evita comer en exceso. Utiliza platos más pequeños y come despacio, saboreando cada bocado.
                    <br><br><strong style='background-color: lightgray; color: black;'>Realiza actividad física regularmente:</strong> La actividad física es fundamental para perder peso y mantener un peso saludable. Intenta realizar al menos 30 minutos de ejercicio moderado la mayoría de los días de la semana.
                    <br><br><strong style='background-color: lightgray; color: black;'>Mantente hidratado:</strong> Bebe mucha agua durante el día para mantenerte hidratado y ayudar a controlar el apetito.
                    <br><br><strong style='background-color: lightgray; color: black;'>Duerme lo suficiente:</strong> Dormir lo suficiente es importante para perder peso y mantener una buena salud en general. La mayoría de los adultos necesitan alrededor de 7-8 horas de sueño por noche.
                    <br><br><strong style='background-color: lightgray; color: black;'>Consulta con un profesional de la salud:</strong> Si tienes dificultades para perder peso por tu cuenta, consulta con un médico o un dietista. Ellos pueden ayudarte a crear un plan de pérdida de peso personalizado y seguro para ti.",
                    "<br><br><strong style='background-color: lightgray; color: black;'>Investigación reciente:</strong> Un estudio publicado en el Journal of the American Medical Association encontró que las personas que perdieron un 5% de su peso corporal experimentaron una reducción significativa en el riesgo de desarrollar diabetes tipo 2. Otro estudio publicado en la revista Obesity encontró que la pérdida de peso moderada puede ayudar a mejorar la calidad del sueño y reducir los síntomas de la apnea del sueño.
                    <br><br><strong style='background-color: lightgray; color: black;'>Conclusión:</strong> Perder peso puede tener un impacto positivo significativo en tu salud y bienestar general. Si estás pensando en perder peso, consulta con un profesional de la salud para que te ayude a crear un plan personalizado y seguro para ti. Recuerda: Perder peso no es una carrera, sino un maratón. Es importante ser paciente y constante en tus esfuerzos. Con el tiempo y la dedicación, puedes alcanzar tus objetivos y disfrutar de una vida más saludable y feliz."
                );                       

                break;
            case "aumento":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                    ['src' => "./img/infoCard/aumento/musculacion.avif", 'alt' => 'musculacion'],
                    ['src' => "./img/infoCard/aumento/musculacion2.avif", 'alt' => 'musculacion2'],
                    ['src' => "./img/infoCard/aumento/buenaSalud_mental.avif", 'alt' => 'buena salud mental'],
                    ['src' => "./img/infoCard/aumento/ejercicio.avif", 'alt' => 'ejercicio'],
                ];
            
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Aumento muscular", // title
                    "El aumento muscular, también conocido como hipertrofia muscular, es el proceso por el cual el tejido muscular experimenta un crecimiento en su tamaño. Este crecimiento se produce a nivel de las fibras musculares, las cuales aumentan su diámetro y longitud. El aumento muscular es el resultado de la adaptación del cuerpo a un estímulo externo, como el entrenamiento de fuerza.", // description
                    "El aumento muscular no se limita a esculpir un físico atractivo, sino que te brinda una serie de beneficios que impactan positivamente en tu salud, bienestar y calidad de vida. Entre ellos, destaca la mejora de la fuerza y resistencia muscular, lo que te permite realizar actividades físicas con mayor facilidad y eficiencia. Además, el aumento muscular te ayuda a controlar tu peso, ya que el tejido muscular quema más calorías que la grasa, incluso en reposo.

                    <br><br>Asimismo, unos músculos más fuertes y desarrollados proporcionan mayor soporte a tus articulaciones y huesos, reduciendo el riesgo de lesiones y previniendo enfermedades como la osteoporosis. El aumento muscular también mejora la salud ósea, aumentando la densidad ósea y fortaleciendo los huesos.
                    
                    <br><br>Por otro lado, el aumento muscular tiene un impacto positivo en la salud mental, mejorando la imagen corporal, la autoestima y la confianza en uno mismo. Además, puede ayudarte a dormir mejor, reducir el estrés y mejorar tu estado de ánimo.
                    
                    <br><br>En definitiva, el aumento muscular no solo se trata de estética, sino que te brinda una serie de beneficios para tu salud física y mental que te permitirán disfrutar de una vida más plena y feliz.", // evaluacion
                    "Esculpir un cuerpo fuerte y saludable no solo requiere esfuerzo en el gimnasio, sino también sabiduría en el descanso. Dormir lo suficiente y permitir la recuperación muscular es fundamental para maximizar el crecimiento muscular.

                    <br><br>Durante el sueño, se liberan hormonas del crecimiento que reparan las microrupturas musculares y estimulan la síntesis de proteínas, proceso clave para la construcción de nuevo tejido muscular. Además, un buen descanso ayuda a reducir los niveles de cortisol, una hormona que puede inhibir el crecimiento muscular.
                    
                    <br><br>La mayoría de los adultos necesitan entre 7 y 8 horas de sueño por noche, pero si entrenas duro, es posible que necesites un poco más. Para mejorar la calidad del sueño, establece un horario regular, crea un ambiente relajante en tu dormitorio, evita la cafeína y el alcohol antes de acostarte, realiza ejercicio con regularidad (evitándolo cerca de la hora de acostarte) y si no puedes conciliar el sueño, levántate y realiza una actividad relajante hasta que te sientas cansado.
                    
                    <br><br>Recuerda, el descanso es tan importante como el entrenamiento en tu camino hacia un cuerpo más fuerte y saludable. Duerme lo suficiente, permite la recuperación muscular y observa cómo tus músculos crecen y se fortalecen de manera efectiva.", // tips e investigaciones
                );
                break;
                
            case "descanso":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                    ['src' => "./img/infoCard/buenDescanso/levantandose.avif", 'alt' => 'levantandose de la cama'],
                    ['src' => "./img/infoCard/buenDescanso/empezandoDia.avif", 'alt' => 'empezando el día'],
                    ['src' => "./img/infoCard/buenDescanso/emociones.avif", 'alt' => 'emocion del descanso'],
                ];
            
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Buen descanso", // title
                    "El descanso, a menudo subestimado, es un pilar fundamental para nuestra salud física y mental. Más allá de ser un simple lapso de inactividad, es un proceso activo en el que el cuerpo se repara, se renueva y se prepara para afrontar los retos del nuevo día.", // description
                    "El buen descanso es un pilar fundamental para mantener una salud óptima y un bienestar integral. Durante el sueño, el cuerpo lleva a cabo procesos vitales de reparación y regeneración, desde la consolidación de la memoria hasta la liberación de hormonas que regulan el estado de ánimo. Una noche de sueño reparador no solo nos deja revitalizados al despertar, sino que también fortalece nuestro sistema inmunológico, ayudándonos a combatir enfermedades y mantenernos en forma.
                    Además, el descanso adecuado juega un papel crucial en nuestra capacidad cognitiva y emocional. La falta de sueño puede afectar negativamente la concentración, el rendimiento mental y la estabilidad emocional, mientras que dormir lo suficiente nos permite enfrentar los desafíos diarios con mayor claridad y calma. Priorizar el buen descanso es, por tanto, una estrategia indispensable para promover la salud integral y alcanzar nuestro máximo potencial en todas las áreas de la vida.", // evaluacion
                    "Para asegurar un buen descanso, es crucial mantener una rutina de sueño constante, acostándose y levantándose a la misma hora todos los días, incluso los fines de semana. Este hábito ayuda a regular el reloj interno del cuerpo, conocido como ritmo circadiano, lo que facilita conciliar el sueño y despertarse sintiéndose más descansado. Además, se recomienda crear un entorno propicio para dormir, manteniendo la habitación fresca, oscura y tranquila, y evitando el uso de dispositivos electrónicos antes de acostarse, ya que la luz azul que emiten puede interferir con la producción de melatonina, la hormona del sueño.
                    Otro consejo respaldado por la ciencia es practicar técnicas de relajación antes de dormir, como la meditación, la respiración profunda o el estiramiento suave. Estas prácticas ayudan a reducir el estrés y la ansiedad, dos factores que pueden interferir con la calidad del sueño. Además, evitar el consumo de cafeína y alcohol antes de acostarse, así como realizar ejercicio regularmente pero evitando hacerlo demasiado cerca de la hora de dormir, también puede contribuir a mejorar la calidad y la duración del sueño.", // tips e investigaciones
                );
                break;                

            case "dejar_de_Fumar":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                    
                ];
            
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Dejar de fumar", // title
                    "Dejar de fumar es una decisión que impacta profundamente tu salud y calidad de vida en múltiples aspectos. Más allá de simplemente abandonar un hábito, es un paso crucial hacia un futuro más saludable y libre de enfermedades relacionadas con el tabaquismo. Al dejar de fumar, no solo estás protegiendo tus pulmones de los daños causados por el humo del tabaco, sino que también estás reduciendo significativamente el riesgo de desarrollar enfermedades cardiovasculares, como enfermedades coronarias y accidentes cerebrovasculares. Además, al liberarte de la adicción al tabaco, experimentarás mejoras notables en tu calidad de vida diaria, desde un aumento en la capacidad pulmonar hasta una piel más saludable y una mayor vitalidad general.", // description
                    "La decisión de dejar de fumar conlleva una serie de beneficios inmediatos y a largo plazo para la salud. En primer lugar, al dejar de fumar, estás protegiendo activamente tu salud cardiovascular al reducir la presión arterial y mejorar la circulación sanguínea. Asimismo, disminuyes significativamente el riesgo de desarrollar cáncer de pulmón y otras enfermedades respiratorias graves. Además, al dejar de fumar, estás contribuyendo a mejorar la calidad del aire en tu hogar y entorno, lo que beneficia no solo a tu salud, sino también a la de tus seres queridos y compañeros de trabajo. Por último, pero no menos importante, dejar de fumar también supone un ahorro económico considerable a largo plazo al eliminar el gasto en cigarrillos y productos relacionados con el tabaco.", // evaluacion
                    "La ciencia respalda una variedad de estrategias para dejar de fumar de manera efectiva y permanente. En primer lugar, considera utilizar terapias de reemplazo de nicotina, como parches, chicles o inhaladores, para reducir los síntomas de abstinencia y aumentar las posibilidades de éxito a largo plazo. Además, es fundamental abordar las situaciones de estrés y ansiedad que pueden surgir al dejar el tabaco mediante técnicas de manejo del estrés, como la meditación, el ejercicio regular y la participación en actividades relajantes. Por último, pero no menos importante, busca apoyo emocional y social durante este proceso, ya sea a través de grupos de apoyo locales, terapia individual o el apoyo de amigos y familiares comprensivos. Recuerda que dejar de fumar es un viaje personal, pero no tienes que hacerlo solo. Con la combinación adecuada de estrategias y apoyo, puedes dejar el tabaco y comenzar a disfrutar de una vida más saludable y libre." // tips e investigaciones
                );
                break;
            
            case "flacoMusculoso":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                    ['src' => "./img/infoCard/flacoMusculoso/definido.avif", 'alt' => 'definido'],
                    ['src' => "./img/infoCard/flacoMusculoso/definido2.avif", 'alt' => 'definido2'],
                    ['src' => "./img/infoCard/flacoMusculoso/flacoMusculoso.avif", 'alt' => 'flaco musculoso'],
                    ['src' => "./img/infoCard/flacoMusculoso/flacoMusculoso2.avif", 'alt' => 'flaco musculoso2'],
                ];
            
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Flaco musculoso", // title
                    "A pesar de tener una constitución delgada, es perfectamente factible ganar músculo y mejorar tu apariencia física. La clave radica en seguir un enfoque disciplinado que combine un entrenamiento de fuerza adecuado con una nutrición equilibrada. Con el tiempo y la dedicación, puedes desarrollar músculos definidos que no solo mejoren tu estética, sino también tu fuerza y resistencia física en general. Este proceso de transformación no solo se trata de cambiar tu aspecto externo, sino de fortalecer tu cuerpo y mente para alcanzar tu máximo potencial.", // description
                    "Optar por el camino del <strong>flaco musculoso</strong> conlleva una serie de beneficios tanto físicos como psicológicos. En primer lugar, ganarás mayor definición muscular y una apariencia más atlética y estéticamente equilibrada. Además, mejorarás tu fuerza y resistencia física, lo que te permitirá llevar a cabo tus actividades diarias con mayor facilidad y eficiencia. Este aumento en la masa muscular también puede impulsar tu autoestima y confianza, ya que te sentirás más seguro y orgulloso de tu cuerpo y logros personales. En resumen, alcanzar el estado de <strong>flaco musculoso</strong> te brinda la posibilidad de alcanzar un aspecto físico más equilibrado y saludable, lo que se traduce en una mejora significativa en tu calidad de vida en general.", // evaluacion
                    "Para aquellos que buscan convertirse en <strong>flacos musculosos</strong>, es fundamental seguir un plan de entrenamiento y nutrición disciplinado y personalizado. Esto implica incorporar ejercicios de fuerza progresiva en tu rutina de entrenamiento para estimular el crecimiento muscular de manera efectiva. Además, asegúrate de consumir una dieta balanceada que incluya suficientes proteínas, carbohidratos y grasas saludables para satisfacer las demandas de tu cuerpo en términos de energía y recuperación muscular. Sin embargo, es importante tener en cuenta que este proceso puede requerir un aumento en el consumo de alimentos y calorías, lo que puede resultar desafiante para algunos individuos. Además, para evitar lesiones musculares, es crucial realizar un entrenamiento adecuado con una técnica adecuada y evitar excederte en el levantamiento de pesos. Al seguir estos consejos respaldados por la ciencia, estarás en el camino correcto para alcanzar tus metas de transformación física de manera segura y efectiva." // tips e investigaciones
                );
                break;
            
            case "adiccion":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                    ['src' => "./img/infoCard/adiccion/adicto_al_movil.avif", 'alt' => 'definido'],
                    ['src' => "./img/infoCard/adiccion/ayuda.avif", 'alt' => 'definido2'],
                    ['src' => "./img/infoCard/adiccion/alegria.avif", 'alt' => 'flaco musculoso'],
                    ['src' => "./img/infoCard/adiccion/alegria2.avif", 'alt' => 'flaco musculoso2'],
                ];
                
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Adicción", // title
                    "La adicción a sustancias o comportamientos puede sumergirte en un ciclo destructivo que afecta tu vida y bienestar de manera significativa. Reconocer que tienes un problema de adicción es el primer paso hacia la recuperación. Es crucial buscar ayuda y comprender las causas subyacentes de la adicción para abordarla de manera efectiva. Con el apoyo adecuado y la determinación, es posible superar la adicción y recuperar el control sobre tu vida. A través de un proceso de recuperación gradual, puedes aprender a manejar los desafíos y las tentaciones, y eventualmente llevar una vida plena y saludable.", // description
                    "Combatir la adicción a TikTok tiene múltiples beneficios, tanto personales como en tus relaciones. Al reconocer el impacto negativo de la app, despejarás tu mente y recuperarás tu enfoque, permitiéndote ser más productivo y alcanzar tus metas. Liberarte de TikTok te permitirá dedicar más tiempo real a cultivar relaciones significativas y duraderas. ¡No eres esclavo de TikTok! Decide retomar el control de tu tiempo y atención. Busca ayuda si lo necesitas y prioriza tu bienestar. Tu salud mental y tus relaciones son más importantes que cualquier app. ¡Despierta! Un mundo de posibilidades te espera más allá de la pantalla.", // evaluacion
                    "Despeja tu mente y recupera tu capacidad de concentración y enfoque.
                    Mejora tu bienestar mental, disfrutando de un sueño más reparador, reduciendo la ansiedad y mejorando tu estado de ánimo en general.
                    Fortalece tus relaciones, dedicando más tiempo real a las personas que te importan y construyendo conexiones más profundas y significativas.
                    Desbloquea tu potencial, enfocando tu energía en alcanzar tus metas y sueños, descubriendo nuevas habilidades, desarrollando tu creatividad y convirtiéndote en la mejor versión de ti mismo.
                    Recupera tu tiempo, dedicándolo a actividades que te aporten valor real como aprender un nuevo idioma, practicar un deporte, leer un libro, conectar con la naturaleza o simplemente disfrutar de momentos de calidad con tus seres queridos." // tips e investigaciones
                );
                break;                
            
            case "noFAP":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                    ['src' => "./img/infoCard/noFAP/mastur.avif", 'alt' => '+18']
                ];
            
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "NoFap", // title
                    "El movimiento NoFap promueve la abstención del consumo de pornografía y la masturbación como un medio para mejorar diversos aspectos de la vida, incluida la salud mental, las relaciones sexuales y la autoestima. Sus seguidores sostienen que al dejar la pornografía, experimentan beneficios como mayor energía, claridad mental y motivación en general. Al adoptar este estilo de vida, se busca cultivar una conexión más profunda con uno mismo y con los demás, priorizando la intimidad genuina sobre la gratificación instantánea.", // description
                    "Adoptar el enfoque NoFap puede resultar en una serie de beneficios significativos para aquellos que buscan mejorar su bienestar emocional y sexual. En primer lugar, al abstenerse de la pornografía y la masturbación, muchas personas reportan mejoras en sus relaciones sexuales y en la intimidad con sus parejas, ya que se centran en experiencias sexuales más auténticas y satisfactorias. Además, al dejar la pornografía, es común experimentar un aumento en la energía, la motivación y el autocontrol, lo que puede conducir a una mayor productividad y satisfacción en la vida cotidiana. Además, al eliminar una fuente de estimulación artificial, se pueden reducir los sentimientos de ansiedad y depresión relacionados con el consumo excesivo de pornografía, lo que contribuye a una mejor salud mental y bienestar emocional.", // evaluacion
                    "Para aquellos que están considerando adoptar el estilo de vida NoFap, es importante tener en cuenta que el proceso puede implicar desafíos y síntomas de abstinencia, como irritabilidad y ansiedad. Sin embargo, mantenerse enfocado en los beneficios a largo plazo y buscar apoyo social pueden ayudar a superar estos obstáculos. Es útil establecer metas claras y realistas, así como desarrollar estrategias de afrontamiento saludables para manejar los momentos de tentación o desafío. Además, buscar recursos y comunidades en línea dedicadas al movimiento NoFap puede proporcionar un apoyo adicional y compartir experiencias con otras personas que están en el mismo viaje. Con el tiempo y el compromiso, muchos individuos encuentran que adoptar el estilo de vida NoFap mejora significativamente su calidad de vida y bienestar emocional." // tips e investigaciones
                );
                break;                

            case "testosterona":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                ];
            
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Testosterona", // title
                    "La testosterona, una hormona fundamental en el cuerpo masculino, desempeña un papel crucial en la salud física y mental. Esta hormona contribuye a una serie de funciones vitales, incluida la salud cardiovascular, la densidad ósea, el desarrollo muscular y el estado de ánimo. Mantener niveles adecuados de testosterona es esencial para promover un funcionamiento óptimo del cuerpo y el bienestar en general.", // description
                    "Los efectos positivos de niveles adecuados de testosterona en el cuerpo son diversos y significativos. En primer lugar, una adecuada cantidad de esta hormona está asociada con un mayor desarrollo de la masa muscular y la fuerza física, lo que puede mejorar la capacidad funcional y la calidad de vida en general. Además, la testosterona contribuye a la salud ósea y la densidad mineral, lo que ayuda a prevenir la osteoporosis y reduce el riesgo de fracturas. Otros beneficios incluyen un aumento en la libido y la función sexual, así como un impulso en la energía y el bienestar general, lo que promueve un estilo de vida activo y saludable.", // evaluacion
                    "Para mantener niveles saludables de testosterona, es importante adoptar hábitos de vida que promuevan su producción y equilibrio en el cuerpo. Esto incluye mantener una dieta balanceada rica en nutrientes esenciales, como proteínas, grasas saludables y vitaminas y minerales, que son importantes para la síntesis de testosterona. Además, el ejercicio regular, especialmente el entrenamiento de fuerza, puede estimular la producción natural de esta hormona. Sin embargo, es importante evitar el exceso de ejercicio, ya que puede tener el efecto contrario. Además, es crucial mantener un peso corporal saludable y controlar el estrés, ya que el estrés crónico puede reducir los niveles de testosterona. En casos donde los niveles de testosterona son bajos, es importante buscar orientación médica para explorar opciones de tratamiento adecuadas y seguras." // tips e investigaciones
                );
                break;                
        
            case "crecimiento_muscular":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                    ['src' => "./img/infoCard/crecimiento/mejoraFuerza.avif", 'alt' => 'mejorando fuerza'],
                    ['src' => "./img/infoCard/crecimiento/fuerza.avif", 'alt' => 'fuerza'],
                    ['src' => "./img/infoCard/crecimiento/superFuerza.avif", 'alt' => 'super fuerza'],
                ];
            
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Crecimiento muscular", // title
                    "El crecimiento muscular es un proceso multifacético que requiere una combinación adecuada de entrenamiento de fuerza, nutrición y descanso. Este proceso implica la hipertrofia muscular, donde las fibras musculares se vuelven más grandes en respuesta al estrés mecánico inducido por el ejercicio. Al seguir un programa de entrenamiento bien estructurado y una dieta equilibrada, puedes maximizar tu potencial de crecimiento muscular y mejorar tanto tu fuerza como tu apariencia física.", // description
                    "Saber cuándo has alcanzado tu límite es complejo, pero algunos indicadores son la progresión lenta, la dificultad para aumentar la fuerza y la mayor facilidad para recuperarse. Si experimentas esto, no te desanimes: enfócate en otros objetivos como la definición muscular, el rendimiento deportivo o mantenerte en forma. Recuerda: los límites existen, pero pueden ampliarse con una estrategia integral que incluya entrenamiento, nutrición y descanso adecuados. Escucha a tu cuerpo, ajusta tu plan y persevera para alcanzar tus metas físicas. El crecimiento muscular tiene límites, tanto genéticos como fisiológicos. Tu genética determina tu potencial máximo, pero puedes maximizarlo con esfuerzo, dedicación y un plan adecuado de entrenamiento y nutrición. La edad, el sexo, el tamaño corporal, el entrenamiento y la nutrición son factores fisiológicos que influyen en el desarrollo muscular.", // evaluacion
                    "Para optimizar el crecimiento muscular, es fundamental mantener una dieta rica en proteínas de alta calidad, carbohidratos complejos y grasas saludables, que proporcionen los nutrientes necesarios para la reparación y el crecimiento muscular. Además, es importante seguir un programa de entrenamiento de fuerza regular que incluya ejercicios compuestos y variados para estimular todos los grupos musculares. La técnica adecuada es crucial para prevenir lesiones y maximizar los resultados. Además, el descanso adecuado es esencial para permitir que los músculos se reparen y crezcan entre sesiones de entrenamiento. La literatura científica respalda la importancia de estos principios en el crecimiento muscular y el rendimiento deportivo." // tips e investigaciones
                );
                break;                
        
            case "maq_vs_pesas":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                    ['src' => "./img/infoCard/maq_peso/armado1.avif", 'alt' => 'hombre armado con espada'],
                    ['src' => "./img/infoCard/maq_peso/armado2.avif", 'alt' => 'hombre armado con arco'],
                    ['src' => "./img/infoCard/maq_peso/maquina.avif", 'alt' => 'maquina'],
                    ['src' => "./img/infoCard/maq_peso/pesoLibre.avif", 'alt' => 'peso libre'],
                ];
            
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Maquinas vs Pesas", // title
                    "El gimnasio se presenta como un campo de batalla donde dos titanes se enfrentan por la supremacía en el entrenamiento: las máquinas de gimnasio y los pesos libres. Cada bando posee ventajas y desventajas únicas, atrayendo a diferentes guerreros en busca de la victoria física..", // description
                    "<h4>Las máquinas de gimnasio</h4>

                    <br><strong style='background-color:lightgray; color:black;'>Guían tu movimiento:</strong> Ofrecen una trayectoria fija que reduce el riesgo de lesiones y facilita el aislamiento muscular.
                    <br><br><strong style='background-color:lightgray; color:black;'>Ideales para principiantes:</strong> Permiten aprender movimientos básicos de forma segura y controlada.
                    <br><br><strong style='background-color:lightgray; color:black;'>Permiten un entrenamiento individualizado:</strong> Muchas máquinas cuentan con ajustes de peso y resistencia para adaptarse a cada nivel.
                    <br><br><strong style='background-color:lightgray; color:black;'>Favorecen la concentración en el músculo objetivo:</strong> Al minimizar la participación de otros grupos musculares, se puede enfocar el trabajo con mayor precisión.
                    
                    <br><br><h4>Los pesos libres</h4>

                    <br><strong style='background-color:lightgray; color:black;'>Exigen mayor control y estabilidad:</strong> Activan una gran cantidad de músculos estabilizadores, mejorando el equilibrio y la propiocepción.
                    <br><br><strong style='background-color:lightgray; color:black;'>Permiten mayor libertad de movimiento:</strong> Facilitan la ejecución de ejercicios multiarticulares más funcionales.
                    <br><br><strong style='background-color:lightgray; color:black;'>Desarrollan fuerza explosiva:</strong> Son ideales para ejercicios que requieren potencia y velocidad.
                    <br><br><strong style='background-color:lightgray; color:black;'>Promueven un mayor gasto calórico:</strong> Al implicar más grupos musculares, se quema más energía durante el entrenamiento.", // evaluacion
                    
                    "¿Cuál elegir? La respuesta depende de tus objetivos y nivel. Si eres principiante, las máquinas te ayudarán a comenzar. Si buscas un entrenamiento completo y funcional, los pesos libres son la clave. Lo ideal es combinarlos: máquinas para aislar y pesos libres para fuerza general y funcionalidad. Recuerda: consulta con un entrenador, comienza con poco peso, aumenta la intensidad poco a poco, realiza los ejercicios con técnica correcta y escucha a tu cuerpo. ¡No importa tu elección, entrena de forma segura y efectiva para alcanzar tus metas!" // tips e investigaciones
                );
                break;                
        
            case "rostro":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                ];
            
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Eliminar papada", // title
                    "La papada, esa molesta acumulación de grasa debajo de la barbilla, puede afectar tu autoestima y hacerte sentir menos seguro de ti mismo. Afortunadamente, existen diversas estrategias para eliminarla y lograr una mandíbula más definida.", // description
                    "
                    <strong style='background-color:lightgray; color:black;'>Ejercicio:</strong> Incluir ejercicios faciales específicos para la zona de la papada puede fortalecer los músculos del cuello y la mandíbula, ayudando a tonificar la zona y reducir la flacidez. Algunos ejemplos son la elevación de la barbilla, la proyección de la lengua y la sonrisa de pez.

                    <br><br><strong style='background-color:lightgray; color:black;'>Cardio:</strong> La actividad cardiovascular regular, como correr, nadar o andar en bicicleta, contribuye a la quema de grasa general, incluyendo la del rostro. Incorpora al menos 30 minutos de cardio moderado a tu rutina diaria para obtener resultados visibles.
                    
                    <br><br><strong style='background-color:lightgray; color:black;'>Dieta:</strong> Una alimentación equilibrada y baja en calorías es esencial para eliminar la grasa de la papada. Reduce el consumo de alimentos procesados, azúcares y grasas saturadas, y opta por frutas, verduras, proteínas magras y cereales integrales.
                    
                    <br><br><strong style='background-color:lightgray; color:black;'>Hidratación:</strong> Beber suficiente agua durante el día ayuda a eliminar toxinas y mantener la piel hidratada, lo que puede contribuir a una apariencia más tonificada en la zona de la papada.
                    
                    <br><br><strong style='background-color:lightgray; color:black;'>Cuidado de la piel:</strong> Aplicar cremas reafirmantes en la zona de la papada puede ayudar a mejorar la elasticidad de la piel y reducir la flacidez. Busca productos que contengan ingredientes como el retinol o el ácido hialurónico.
                    
                    <br><br><strong style='background-color:lightgray; color:black;'>Recuerda:</strong> La eliminación de la papada requiere constancia y paciencia. No esperes resultados instantáneos, pero si implementas estas estrategias de manera regular, podrás ver una notable mejora en la definición de tu mandíbula y aumentar tu confianza en ti mismo.", // evaluacion
                    
                    "Combatir la papada requiere un enfoque integral que combine hábitos saludables y estrategias específicas. Si bien cada caso es único y un plan personalizado por un profesional siempre será ideal, te comparto un consejo clave para comenzar tu camino hacia una mandíbula definida:
                    <br><br><strong style='background-color:lightgray; color:black;'>Prioriza la alimentación:</strong> Adoptar una dieta equilibrada y baja en calorías es fundamental para eliminar la grasa corporal general, incluyendo la del rostro. Reduce el consumo de alimentos procesados, azúcares y grasas saturadas, y opta por frutas, verduras, proteínas magras y cereales integrales. Aumentar tu ingesta de fibra también puede ser beneficioso, ya que favorece la saciedad y ayuda a controlar el peso.
                    <br><br>Recuerda que este consejo es solo un punto de partida. La constancia, la paciencia y la combinación de diferentes estrategias serán claves para alcanzar tus objetivos. Consulta con un profesional de la salud o un nutricionista para obtener un plan personalizado que se adapte a tus necesidades y te ayude a lograr una mandíbula más definida de manera saludable y efectiva." // tips e investigaciones
                );
                break;
        
            case "bebidas_energeticas":
                // Guardamos en un array las imagenes y sus alt para no repetir varias veces en los parámetros
                $imagesArray = [
                    ['src' => "./img/infoCard/energy/bebidas.avif", 'alt' => 'bebidas energéticas'],
                    ['src' => "./img/infoCard/energy/bebidas2.avif", 'alt' => 'cogiendo bebidas enrgéticas'],
                    ['src' => "./img/infoCard/energy/bebidas3.avif", 'alt' => 'mas bebidas enrgéticas'],
                ];
            
                // Ahora llamamos a la función info_card y le ponemos sus respectivos parámetros
                info_Card(
                    $imagesArray,
                    "Bebidas energéticas", // title
                    "Las bebidas energéticas son productos que contienen altas dosis de cafeína y otros estimulantes diseñados para promover la alerta y la energía. Estas bebidas suelen comercializarse como soluciones rápidas para combatir la fatiga y mejorar el rendimiento físico y mental. Sin embargo, el consumo excesivo o frecuente de estas bebidas puede tener efectos negativos en la salud. Aunque pueden proporcionar un impulso temporal, el consumo excesivo de estas bebidas puede llevar a problemas como aumento de la presión arterial, insomnio y dependencia.", // description
                    "El consumo de bebidas energéticas puede proporcionar varios beneficios temporales, como aumento en la energía y la alerta mental, mejora en el rendimiento físico y la resistencia, mayor concentración y enfoque durante actividades cognitivas, y comodidad y portabilidad como alternativa al café u otras bebidas con cafeína. Sin embargo, es importante tener en cuenta los posibles efectos secundarios y riesgos para la salud asociados con el consumo excesivo o frecuente de estas bebidas.", // evaluacion
                    "Para minimizar los riesgos para la salud asociados con el consumo de bebidas energéticas, es importante seguir algunos consejos respaldados por la investigación científica. Esto incluye limitar el consumo de estas bebidas y evitar su consumo en exceso, especialmente en combinación con otras fuentes de cafeína o durante actividades físicas intensas. Además, se recomienda evitar el consumo de bebidas energéticas antes de acostarse para prevenir el insomnio y otros problemas relacionados con el sueño. También es importante estar atento a los posibles signos de dependencia de la cafeína y reducir gradualmente el consumo si es necesario. En caso de experimentar efectos secundarios negativos o preocupantes, es recomendable buscar orientación médica adecuada." // tips e investigaciones
                );
                break;                
        }
    ?>

</main>
<?php include("footer.php") ?>