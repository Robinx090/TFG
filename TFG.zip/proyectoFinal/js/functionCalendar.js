$(document).ready(function() {
    const $calendario = $("#calendar");

    // Obtenemos la fecha y hora actual
    const ahora = new Date();
    const anioActual = ahora.getFullYear();
    const mesActual = ahora.getMonth();

    // Función para obtener o inicializar el estado de selección desde localStorage
    function obtenerEstadoSeleccion(clave) {
        let estadoSeleccion = localStorage.getItem(clave);
        if (!estadoSeleccion) {
            // Si no hay estado guardado, inicializo un objeto vacío
            estadoSeleccion = {};
        } else {
            // Parseamos el estado guardado
            estadoSeleccion = JSON.parse(estadoSeleccion);
        }
        return estadoSeleccion;
    }

    // Función para guardar el estado de selección en localStorage
    function guardarEstadoSeleccion(clave, estadoSeleccion) {
        localStorage.setItem(clave, JSON.stringify(estadoSeleccion));
    }

    // Ahora obtendremos los días que tiene el mes y el primer día de la semana
    let diasDelMes = new Date(anioActual, mesActual + 1, 0).getDate();
    let primerDiaMes = new Date(anioActual, mesActual, 1).getDay();

    // Generamos los días vacíos que vaya a tener el primer día del mes
    for (let i = 1; i < primerDiaMes; i++) {
        let $celdaVacia = $("<div>").addClass("day empty");
        $calendario.append($celdaVacia);
    }

    // Recuperamos el estado de selección guardado
    let estadoSeleccion = obtenerEstadoSeleccion('calendarSelection');

    // Una vez que hemos generado los campos vacíos, nos dispondremos a insertar los días de la celda
    for (let dia = 1; dia <= diasDelMes; dia++) {
        let $celdaDia = $("<div>").addClass("day").text(dia);
        let fechaCelda = new Date(anioActual, mesActual, dia);

        // Verificamos si la celda está seleccionada según el estado guardado
        if (estadoSeleccion[dia]) {
            $celdaDia.addClass("selected");
        }

        // Al hacer clic, guardamos el estado de selección y cambiamos la clase
        $celdaDia.on("click", function() {
            $(this).toggleClass("selected");

            // Actualizamos el estado de selección y lo guardamos
            if ($(this).hasClass("selected")) {
                estadoSeleccion[dia] = true;
            } else {
                delete estadoSeleccion[dia];
            }
            guardarEstadoSeleccion('calendarSelection', estadoSeleccion);
        });

        // Y lo insertamos en nuestro calendario
        $calendario.append($celdaDia);
    }
});
