// Calculadora de Calorías
$(document).ready(function() {
    // Utilizo jQuery para asignar el evento de entrada al campo 'calCalorias'
    $('#calCalorias').on('input', calCalorias);

    function calCalorias() {
        // Obtengo los valores de entrada del usuario
        const edad = parseInt($('#edad').val());
        const peso = parseFloat($('#peso').val());
        const estatura = parseInt($('#estatura').val());
        const sexo = $('input[name="sexo"]:checked').val();
        const actividad = $('#actividad').val();

        let tmb;

        // Calculo la Tasa Metabólica Basal (TMB) según el sexo del usuario
        if (sexo === 'hombre') {
            tmb = 10 * peso + 6.25 * estatura - 5 * edad + 5;
        } else {
            tmb = 10 * peso + 6.25 * estatura - 5 * edad - 161;
        }

        // Defino el factor de actividad según el nivel de actividad física del usuario
        let factorActividad;
        switch (actividad) {
            case 'sedentario':
                factorActividad = 1.2;
                break;
            case 'ligero':
                factorActividad = 1.375;
                break;
            case 'moderado':
                factorActividad = 1.55;
                break;
            case 'activo':
                factorActividad = 1.725;
                break;
            case 'muyActivo':
                factorActividad = 1.9;
                break;
            default:
                factorActividad = 1.2;
        }

        // Calculo las calorías necesarias para mantener el peso y perder peso
        const mantenerPeso = tmb * factorActividad;
        const perderMedioKilo = mantenerPeso - 500;
        const perderUnKilo = mantenerPeso - 1000;

        // Actualizo los resultados en el DOM
        $('#mantenerPeso').text(Math.round(mantenerPeso));
        $('#perderUnaLibra').text(Math.round(perderMedioKilo));
        $('#perderDosLibras').text(Math.round(perderUnKilo));
    }
    calCalorias();
})

// Calculadora de IMC
$(document).ready(function() {
    // Asigno el evento de entrada al campo 'calIMC' usando jQuery
    $('#calIMC').on('input', cal_IMC);

    function cal_IMC() {
        // Obtengo los valores de entrada del usuario
        const peso = parseFloat($('#peso').val());
        const altura = parseFloat($('#altura').val()) / 100; // Convertir a metros

        // Verifico si los valores son válidos
        if (isNaN(peso) || isNaN(altura) || altura === 0) {
            $('#imcValor').text('N/A');
            borrarColor();
            return;
        }

        // Calculo el IMC
        const imc = peso / (altura * altura);
        $('#imcValor').text(imc.toFixed(1));

        borrarColor();

        // Destaco la categoría correspondiente según el IMC calculado
        if (imc < 16) {
            color('catMuyBajoPeso1', 'text-yellow');
        } else if (imc >= 16 && imc < 18.5) {
            color('catBajoPeso', 'text-yellow');
        } else if (imc >= 18.5 && imc < 25) {
            color('catNormal', 'text-green');
        } else if (imc >= 25 && imc < 30) {
            color('catSobrepeso', 'text-red');
        } else if (imc >= 30 && imc < 35) {
            color('catObeso1', 'text-red');
        } else if (imc >= 35 && imc < 40) {
            color('catObeso2', 'text-red');
        } else {
            color('catObeso3', 'text-red');
        }
    }

    function borrarColor() {
        const categories = [
            'catMuyBajoPeso1', 'catMuyBajoPeso2', 'catBajoPeso',
            'catNormal', 'catSobrepeso', 'catObeso1', 'catObeso2', 'catObeso3'
        ];

        // Quito la clase de resalte de todas las categorías
        categories.forEach(id => {
            $('#' + id).removeClass();
        });
    }

    function color(categoryId, colorClass) {
        // Agrego la clase de resalte a la categoría correspondiente
        $('#' + categoryId).addClass('highlight ' + colorClass);
    }

    cal_IMC();
})

// Calculadora de Proteínas
$(document).ready(function() {
    // Asigno el evento de entrada al campo 'calProteinas' usando jQuery
    $('#calProteinas').on('input', calProtein);

    function calProtein() {
        // Obtengo los valores de entrada del usuario
        const peso = parseFloat($('#peso').val());
        const nivelActividad = $('input[name="nivelActividad"]:checked').val();
        const esVegetariano = $('#vegetariano').is(':checked');

        // Verifico si el valor de peso es válido
        if (isNaN(peso) || peso <= 0) {
            $('#proteinaValor').text('N/A');
            return;
        }

        // Defino el factor de proteína según el nivel de actividad del usuario
        let factorProteina;
        switch (nivelActividad) {
            case 'bajoEntrenamiento':
                factorProteina = 0.8;
                break;
            case 'resistencia':
                factorProteina = 1.2;
                break;
            case 'fuerza':
                factorProteina = 1.6;
                break;
            default:
                factorProteina = 0.8;
        }

        // Aumento el factor de proteína en un 20% si el usuario es vegetariano
        if (esVegetariano) {
            factorProteina *= 1.2;
        }

        // Calculo la proteína recomendada y actualizo el resultado en el DOM
        const proteinaRecomendada = peso * factorProteina;
        $('#proteinaValor').text(proteinaRecomendada.toFixed(1));
    }

    calProtein();
})