$(document).ready(function() {
    // Sólo se enviarán los formularios cuándo los campos estén llenos
    $('#login').submit(function(event) {
        // Detenemos el envío por defecto y lo validamos
        event.preventDefault();

        // El campo dónde van los errores debe estar vacío
        $(".errores").text("");

        // Guardamos las variables del usuario y la contraseña
        let user = $('#usuario').val();
        let clave = $('#pass').val();

        // Comprobaremos de que no tengan espacios ni por delante ni por detrás y que no estén vacíos
        if (user.trim() === '' && clave.trim() === '' || user == "" || clave == "") {
            $(".errores").text("Los campos no deben estar vacíos");
        }else{
            // En el caso de que los campos no estén vacíos podrá enviarse al php
            this.submit();
        }
    });

    $("#register").submit(function(e){
        e.preventDefault();

        // Al principio el campo errores deberá estar vacío
        $(".errores").text("");
        let user = $('#usuario').val();
        let clave = $('#pass').val();
        let email = $('#email').val();
        let preguntaSeguridad = $('#preguntaSeguridad').val();

        // Comprobaremos de que no tengan espacios ni por delante ni por detrás y que no estén vacíos
        if (user.trim() === '' && clave.trim() === '' && email.trim() && preguntaSeguridad.trim() ==='' || email == "" || user == "" || clave == "" || preguntaSeguridad == "") {
            $(".errores").text("Los campos no deben estar vacíos");
        }else{
            // En el caso de que los campos no estén vacíos podrá enviarse al php
            this.submit();
        }
    })

    $("#olvidar").submit(function(e){
        e.preventDefault();

        // Al principio el campo errores deberá estar vacío
        $(".errores").text("");
        let email = $('#email').val();
        let preguntaSeguridad = $('#preguntaSeguridad').val();

        // Comprobaremos de que no tengan espacios ni por delante ni por detrás y que no estén vacíos
        if (preguntaSeguridad.trim() ==='' && email.trim() ==='' || email == "" || preguntaSeguridad == "") {
            $(".errores").text("Los campos no deben estar vacíos");
        }else{
            // En el caso de que los campos no estén vacíos podrá enviarse al php
            this.submit();
        }
    })

    $("#resetPass").submit(function(e){
        e.preventDefault();

        // Al principio el campo errores deberá estar vacío
        $(".errores").text("");
        let newPass = $('#newPass').val();

        // Comprobaremos de que no tengan espacios ni por delante ni por detrás y que no estén vacíos
        if (newPass == "") {
            $(".errores").text("Los campos no deben estar vacíos");
        }else{
            // En el caso de que los campos no estén vacíos podrá enviarse al php
            this.submit();
        }
    })

    $('#contactanos').submit(function(event) {
        // Detenemos el envío por defecto y lo validamos
        event.preventDefault();

        // El campo dónde van los errores debe estar vacío
        $(".errores").text("");

        // Guardamos las variables del usuario y la contraseña
        let nombre = $('#nombre').val();
        let email = $('#email').val();
        let problema = $('#problema').val();

        // Comprobaremos de que no tengan espacios ni por delante ni por detrás y que no estén vacíos
        if (nombre.trim() === '' && email.trim() === '' && problema.trim() === '' || nombre == "" || email == "" || problema == "") {
            $(".errores").text("Los campos no deben estar vacíos");
        }else{
            // En el caso de que los campos no estén vacíos podrá enviarse al php
            this.submit();
        }
    });

    $('#rutinas').submit(function(event) {
        event.preventDefault();

        $(".errores").text("");

        let nivel = $('input[name="nivel"]:checked').val();
        let maquinaria = $('input[name="maquinaria"]:checked').val();

        if (!nivel || !maquinaria) {
            $(".errores").text("Debe seleccionar una opción para todos los campos.");
        } else {
            this.submit();
        }
    });
});