$(document).ready(function(){
    const nav = $("#nav");
    const open = $("#abrir");
    const close = $("#cierre");
    const subMenu = $('.nav-sub-list');

    /* Cuándo le demos click al abrir, le mostrará la barra de navegación */
    open.click(function(){
        nav.addClass("visible");
    });

    /* Cuándo le demos click al abrir, le ocultará de nuevo la barra de navegación */
    close.click(function(){
        nav.removeClass("visible");
    });

    // Creamos una función la cuál detecte cualquier evento en el documento
    $(document).click(function(event) { 
        // En el caso de que sea distinto a la variable abrir que pertenece a un botón, entonces eliminará la clase
        if (!$(event.target).closest(open).length && !$(event.target).closest(subMenu).length) {
            nav.removeClass("visible");
            subMenu.removeClass('openJS');
        }
    });

    // Al hacer click en el submenu, administraremos la clase openJS en la clase que contiene el subMenu
    $('#subMenu').click(function(){
        subMenu.toggleClass('openJS');
    });
});