<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1"/>

    <title>WayWolf</title>
    <!-- Ícono del sitio --> 
    <link rel="shortcut icon" href="./img/icon/icon_logo.ico"/>
    <!-- BOOTSTRAP CSS/ICON-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <!-- BOOTSTRAP JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <!-- JQUERY y JS-->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="./js/menu.js"></script>
    <script src="./js/forms.js"></script>
    <script src="./js/functionCalendar.js"></script>
    <script src="./js/functionCalorias.js"></script>

    <!-- CSS PERSONALIZADO-->
    <link rel="stylesheet" href="./styles/styleHeader.css">
    <link rel="stylesheet" href="./styles/styleIndice.css">
    <link rel="stylesheet" href="./styles/styleFooter.css">
    <link rel="stylesheet" href="./styles/styleForm.css">
    <link rel="stylesheet" href="./styles/styleRutina.css">
</head>
<body>
    <!-- Ponemos la etiqueta header en la que dentro se encontrará el logo y la barra de navegación -->
    <header>
        <!-- IMAGEN DEL LOGO -->
        <a href="index.php"> <img src="./img/icon/logo.jpeg" alt="Logo" class="logo"> </a>
            <button class="open-menu" id ="abrir"><i class="bi bi-list"></i></button>
            <nav class ="nav" id ="nav">
                <button class="close-menu" id="cierre"><i class="bi bi-x"></i></button>
                <!-- Todos los elementos de mi barra de navegación -->
                <ul class="nav-list">
                    <!-- MENÚ INFOMRACIÓN --> 
                    <li> <a href="index.php"> Información </a> </li>

                    <!-- MENÚ RUTINA --> 
                    <li> <a href="forms.php?tipo=rutinas">Rutinas</a> </li>

                    <!-- MENÚ CALCULADORAS -->
                    <li class="menuCalc" id="subMenu"> Calculadoras
                        <ul class="nav-sub-list">
                            <li><a href="forms.php?tipo=calCalorias">Calorías</a></li>
                            <li><a href="forms.php?tipo=calIMC">IMC (Índice Masa Muscular)</a></li>
                            <li><a href="forms.php?tipo=calProteina">Proteínas</a></li>
                        </ul>
                    </li>
                    
                    <!-- LOGIN -->
                    <li> <a href="forms.php?tipo=login" class="icon-login"> <img src="./img/icon/login.png" alt="Login"> </a> </li>
                </ul>
            </nav>
    </header>
