<?php
    // Iniciamos una sesión
    session_start();

    // Accedemos al recurso una sóla vez y guardamos en conexion la llamada a la base de datos
    require("../../../private/conexionBD.php");
    require_once("funcionalidadesBD.php");

    $conexion = conectarBaseDatos();
    $estado = $_GET['estado']; // Guardamos el estado que se haya enviado por el método POST

    // Dependiendo del caso, se hará una acción u otra
    switch($estado){
        case "registro":
            // Recibimos los datos de nuestro Formulario
            $email = $_POST["email"];
            $usuario = $_POST["usuarioRegister"];
            $pass = $_POST["passRegister"];
            $preguntaSeguridad = $_POST["preguntaSeguridad"];

            // Ahora guardaremos ambos en un array de datos de usuario
            $datosUsuario = array(
                'usuario' => $usuario,
                'clave' => $pass,
                'email' => $email,
                'preguntaSeguridad' => $preguntaSeguridad
            );

            // Comprobamos la función de insertarDatos, si devuelve TRUE, los datos se habrán insertado correctamente
            if (insert($conexion, 'usuarios', $datosUsuario)) {
                // Al insertar los datos correctamente, le mandaremos a rutinas
                $_SESSION['user'] = $usuario;
                $_SESSION['conectado'] = true;
                header("Location: ../forms.php?tipo=rutinas");
                exit();
            }else{
                $_SESSION['usuarioExiste'] = "El nombre de usuario ya existe";
                header("Location: ../forms.php?tipo=register");
                exit();
            }
            break;

        case "login":
            // Recibimos los datos de nuestro Formulario
            $user = $_POST["usuarioLogin"];
            $password = $_POST["passLogin"];
        
            // Ahora comprobaremos si se encontró el usuario o no
            if (select($conexion, "usuarios", $user, $password) ) {
                // En el caso de que se encuentre, se habrá logueado con éxito y guardaremos la session
                $_SESSION['user'] = $user;
                $_SESSION['conectado'] = true;
                header("Location: ../forms.php?tipo=rutinas");
                exit();
            } else {
                // En el caso contrario, volverá al login sin haberse registrado
                $_SESSION['error'] = "El usuario no se ha podido encontrar" ;
                header("Location: ../forms.php?tipo=login");
                exit();
            }
            break;

        case "olvido":
            // Recibimos los datos de nuestro Formulario
            $email = $_POST["email"];
            $preguntaSeguridad = $_POST["preguntaSeguridad"];
        
            // Ahora comprobaremos si se encontró el usuario o no
            if (checkPass($conexion, "usuarios", $email, $preguntaSeguridad) ) {
                // En el caso de que se encuentre se le enviará a resetear la contraseña y creamos una session
                $_SESSION['canReset'] = true;
                header("Location: ../forms.php?tipo=resetPass");
                exit();
            } else {
                // En el caso contrario, volverá al login sin haberse registrado
                $_SESSION['error'] = "El email o la pregunta de seguridad no son correctos" ;
                header("Location: ../forms.php?tipo=olvido");
                exit();
            }
            break;
        
        case "resetPass":
            // Recibimos los datos de nuestro Formulario
            $newPass = $_POST["newPass"];
        
            // Verificamos que la sesión 'email' esté configurada
            if (isset($_SESSION['canReset'])) {
                // Llamamos a la función para actualizar la contraseña y reenvíamos al usuario al login
                updatePass($conexion, "usuarios", $newPass, $_SESSION['email']);
                header("Location: ../forms.php?tipo=login");
                exit();
            } else {
                // Si la sesión 'email' no está configurada, redirigir al formulario de olvido
                $_SESSION['error'] = "Sesión inválida o expirada";
                header("Location: ../forms.php?tipo=olvido");
                exit();
            }
            
            break;

        case "rutinas":
            // Recibimos los datos de nuestro Formulario
            $objetivo = $_POST["objetivo"];
            $nivel = $_POST["nivel"];
            $dieta = $_POST["dieta"];
            $maquinaria = $_POST["maquinaria"];

            // En el caso de que no tenga una rutina, deberemos crearle una mediante las especificaciones que nos a dado
            // Haremos una condición para controlar si el usuario a puesto que tiene maquinaria o no
            if($maquinaria == "si"){
                // Hacemos otra condición para saber si a querido dieta o no
                if($dieta == "si"){
                    crearRutina($conexion, "ejercicios", $nivel, $objetivo, 1, 1);
                }else{
                    crearRutina($conexion, "ejercicios", $nivel, $objetivo, 1, 0);
                }

            }else if($maquinaria == "no"){
                // Hacemos otra condición para saber si a querido dieta o no
                if($dieta == "si"){
                    crearRutina($conexion, "ejercicios", $nivel, $objetivo, 0, 1);
                }else{
                    crearRutina($conexion, "ejercicios", $nivel, $objetivo, 0, 0);
                }
            }
            header("Location: ../forms.php?tipo=rutinas");
            exit();
            break;

        case "rutina0":
            // Comprobamos de que se haya puesto una accion
            if(isset($_POST['accionRutina'])){
                $id_usuario = $_SESSION["id_usuario"];
                // En el caso de que devuelva true, se devolverá a la página
                if(rutina0($conexion, $id_usuario)){
                    header("Location: ../forms.php?tipo=rutinas");
                    exit();
                }
            }
            break;
        
        case "otraDieta":
            // Comprobamos de que se haya puesto una accion
            if(isset($_POST['crearDieta'])){
                $id_usuario = $_SESSION["id_usuario"];

                // En el caso de que devuelva true, se devolverá a la página
                if(crearOtraDieta($conexion, $id_usuario)){
                    header("Location: ../forms.php?tipo=rutinas");
                    exit();
                }
            }
            break;
    }
?>
