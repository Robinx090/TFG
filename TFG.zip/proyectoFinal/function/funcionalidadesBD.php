<?php
    // Primero creamos la función que se encargará de insertar datos en la BD
    function insert($conexion, $tabla, $datos){

        // Antes de registrar al usuario, comprobaremos de que no haya otro nombre de usuario igual 
        if ($tabla === 'usuarios' && isset($datos['usuario'])) {
            $usuario = $datos['usuario'];
            $sql = "SELECT COUNT(*) FROM usuarios WHERE usuario = :usuario";
            $stmt = $conexion->prepare($sql);
            $stmt->bindValue(':usuario', $usuario);
            $stmt->execute();
            $count = $stmt->fetchColumn();

            // En el caso de que haya encontrado alguno, devolveremos FALSE
            if ($count > 0) {
                return false;
            }
        }

        // Guardamos las claves y sus valores del parámetro datos
        $columnas = implode(', ', array_keys($datos));
        $valores = ':' . implode(', :', array_keys($datos));

        // Creamos nuestro SQL y lo preparamos para que sólo lo tenga que ejecutar
        $sql = "INSERT INTO $tabla ($columnas) VALUES($valores)";
        $stmt = $conexion->prepare($sql);

        // Ahora asignaremos los valores a los parámetro de sentencia
        foreach ($datos as $clave => $valor) {
            $stmt->bindValue(":$clave", $valor);
        }

        // En el caso de que se ejecute correctamente nos devolverá TRUE
        if ($stmt->execute()) {
            return true;
        }
    }

    // Cogiendo los siguientes parámetros, comprobaremos si el usuario se encuentra en la BD
    function select($conexion, $tabla, $user, $pass){
        // Creamos nuestro SQL y lo preparamos para que sólo lo tenga que ejecutar el sql
        $sql = "SELECT usuario, clave FROM $tabla WHERE usuario = :user";
        $stmt = $conexion->prepare($sql);
        $stmt->bindValue(":user", $user);
        $stmt->execute();
    
        // Recuperamos la fila de la tabla usuario, que se haya encontrado en caso de que el nombre de usuario esté
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        // Ahora comprobaremos si se encontró algo
        if ($usuario && $pass == $usuario['clave']) {
            return true;
        } else {
            return false;
        }
    }

    // Comprobaremos si el correo existe en nuestra BD
    function checkPass($conexion, $tabla, $email, $preguntaSeguridad){

        // Creamos nuestro SQL y lo preparamos para que sólo lo tenga que ejecutar el sql
        $sql = "SELECT email, preguntaSeguridad FROM $tabla WHERE email = :email AND preguntaSeguridad = :preguntaSeguridad";
        $stmt = $conexion->prepare($sql);
        $stmt->bindValue(":email", $email);
        $stmt->bindValue(":preguntaSeguridad", $preguntaSeguridad);
        $stmt->execute();    
        $puedeResetear = $stmt->fetch(PDO::FETCH_ASSOC);

        // En el caso de que todo coincida, se devolverá TRUE
        if ($puedeResetear) {
            return true;
        } else {
            return false;
        }
    }

    // Actualizamos la contraseña de nuestra base de datos
    function updatePass($conexion, $tabla, $newPass, $email){

        // Creamos nuestro SQL y lo preparamos para que sólo lo tenga que ejecutar el sql
        $sql = "UPDATE $tabla SET clave = :newPass WHERE email = :email";
        $stmt = $conexion->prepare($sql);
        $stmt->bindValue(":newPass", $newPass);
        $stmt->bindValue(":email", $email);
        $stmt->execute();
    }

    // Escogemos la rutina dependiendo de las opciones que haya puesto el usuario
    function crearRutina($conexion, $tabla, $nivel, $objetivo, $pesas, $dieta){
        $dias = 0;
        // Según el nivel, se le pondrá unos días de entrenamiento u otros
        switch ($nivel) {
            case 'principiante':
                $dias = rand(2,3);
                break;
            case 'intermedio':
                $dias = rand(4, 5);
                break;
            case 'avanzado':
                $dias = rand(5, 6);
                break;
        }
    
        // Inicializamos nuestro array de rutinas
        $id_ejercicios = array();
        $id_dieta = array();
    
        for ($i = 0; $i < $dias; $i++) {
            $id_ejercicios = array();
            $ejercicios_necesarios = $dias * 3;

            // Consulta SQL para obtener los ejercicios de sus partes del cuerpo aleatorias
            $consulta = "
                SELECT *, ROW_NUMBER() OVER (PARTITION BY parte ORDER BY RAND()) AS row_num
                FROM $tabla WHERE pesas = :pesas LIMIT $ejercicios_necesarios;";
    
            // Ejecutamos la consulta
            $stmt = $conexion->prepare($consulta);
            $stmt->bindValue(":pesas", $pesas, PDO::PARAM_INT);
            $stmt->execute();
            $ejercicios = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            // En el caso de que haya algún ejercicio, se guardará en un array
            if (count($ejercicios) > 0) {
                // Guardamos todos los ID de los ejercicios generados
                foreach ($ejercicios  as $ejercicio) {
                    $id_ejercicios[] = $ejercicio['id'];
                }
            } else {
                return array("error" => "No se encontraron ejercicios para el día " . ($i + 1));
            }

            $id_dieta = array();
            // En el caso de que la variable contenga un valor mayor que 0, significará TRUE
            if ($dieta > 0) {
                // Creamos nuestro SQL y lo preparamos para que sólo lo tenga que ejecutar el sql
                $sql = "SELECT id FROM dieta WHERE objetivo = :objetivo ORDER BY RAND()";
                $stmt = $conexion->prepare($sql);
                $stmt->bindValue(":objetivo", $objetivo, PDO::PARAM_STR);
                $stmt->execute();

                // Se devuelven los valores de la primera columna, qué es en dónde se encuentra el id
                $id_dieta = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
                while (count($id_dieta) < 7) {
                    $id_dieta[] = $id_dieta[array_rand($id_dieta)];
                }
            } else {
                // Si $dieta es 0 o menos, llenar el array con 0s
                $id_dieta = array_fill(0, 7, 0);
            }

            // Ajustamos el tamaño de nuestros arrays
            $max_size = max(count($id_ejercicios), count($id_dieta));
            $id_ejercicios = array_pad($id_ejercicios, $max_size, $id_ejercicios[array_rand($id_ejercicios)]);
            $id_dieta = array_pad($id_dieta, $max_size, $id_dieta[array_rand($id_dieta)]);

            // Creamos nuestro SQL en el cuál elegirá el id de la tabla usuarios
            $sql2 = "SELECT id FROM usuarios WHERE usuario = :user";
            $stmt2 = $conexion->prepare($sql2);
            $stmt2->bindValue(":user", $_SESSION['user'], PDO::PARAM_STR);
            $stmt2->execute();
        
            // Recuperamos la fila de la tabla usuario, que se haya encontrado en caso de que el nombre de usuario esté
            $id_usuario = $stmt2->fetch(PDO::FETCH_COLUMN, 0);
    
            // Preparamos la consulta de inserción en la tabla rutina
            $sql3 = "INSERT INTO rutina (id_usuario, id_ejercicios, id_dieta, objetivo, nivel, pesas) VALUES(:id_usuario, :id_ejercicios, :id_dieta, :objetivo, :nivel, :pesas)";
            $stmt3 = $conexion->prepare($sql3);

            // Recorrer los IDs de ejercicios y ejecutar la inserción para cada uno
            for ($i = 0; $i < $max_size; $i++) {
                // Vinculamos los valores
                $stmt3->bindValue(":id_usuario", $id_usuario, PDO::PARAM_INT);
                $stmt3->bindValue(":id_ejercicios", $id_ejercicios[$i], PDO::PARAM_INT);
                $stmt3->bindValue(":id_dieta", $id_dieta, PDO::PARAM_INT);
                $stmt3->bindValue(":objetivo", $objetivo, PDO::PARAM_STR);
                $stmt3->bindValue(":nivel", $nivel, PDO::PARAM_STR);
                $stmt3->bindValue(":pesas", $pesas);
        
                // Ejecutar la consulta de inserción
                $stmt3->execute();
            }
        }
    }

    // Devolvemos el id del usuario
    function id_usuario($conexion, $usuario, $tabla){
        // Creamos nuestro SQL y lo preparamos para que sólo lo tenga que ejecutar el sql
        $sql = "SELECT id FROM $tabla WHERE usuario = :user";
        $stmt = $conexion->prepare($sql);
        $stmt->bindValue(":user", $usuario);
        $stmt->execute();
    
        // Recuperamos la fila de la tabla usuario, que se haya encontrado en caso de que el nombre de usuario esté
        $id = $stmt->fetch(PDO::FETCH_ASSOC);

        // Ahora comprobaremos si se encontró algo
        if ($id) {
            return $id;
        }
    }

    // Con esta función comprobaremos si el usuario tiene o no una rutina
    function tieneRutina($conexion, $id_usuario) {
        $sql = "SELECT COUNT(*) FROM rutina WHERE id_usuario = :id_usuario";
        $stmt = $conexion->prepare($sql);
        $stmt->bindValue(":id_usuario", $id_usuario, PDO::PARAM_INT);
        $stmt->execute();
        if ($stmt->fetchColumn() > 0){
            return true;
        }
        return false;
    }    

    // Obtenemos los id de ejercicios y dieta
    function obtenerIDs($conexion, $userID) {
        // Ejecutamos la consulta
        $sql = "SELECT id_ejercicios, id_dieta FROM rutina WHERE id_usuario = :id_usuario";
        $stmt = $conexion->prepare($sql);
        $stmt->bindValue(":id_usuario", $userID, PDO::PARAM_INT);
        $stmt->execute();
        $ids = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        // Inicializamos los arrays
        $id_ejercicios = [];
        $id_dieta = [];
    
        // En el caso de que haya algún registro, lo procesamos
        if ($ids) {
            foreach ($ids as $id) {
                if (!empty($id['id_ejercicios'])) {
                    $id_ejercicios = array_merge($id_ejercicios, explode(",", $id['id_ejercicios']));
                }
                if (!empty($id['id_dieta'])) {
                    $id_dieta = array_merge($id_dieta, explode(",", $id['id_dieta']));
                }
            }
        }
    
        return [
            'ejercicios' => $id_ejercicios,
            'dieta' => $id_dieta
        ];
    }

    /* Creamos una función la cuál acceda a nuestra base de datos de rutina 
    y mediante los id mostraremos la tabla ejercicios y la tabla dieta en el caso de que tenga*/
    function accederRutina($conexion, $id_usuario, $id_ejercicios, $id_dieta) {
        // Inicializamos el array de rutina
        $rutina = array();
        // Inicializamos y obtenemos los datos de los ejercicios
        $ejercicios = array();
        // Aquí es dónde separamos por comas todos los id que tenemos en nuestro array id_ejercicios
        $sql_ejercicios = "SELECT * FROM ejercicios WHERE id IN (".implode(",", $id_ejercicios).")";
        $stmt_ejercicios = $conexion->query($sql_ejercicios);

        // Mientras haya una fila con ejercicios, se ejecutará está sentencia
        while ($row = $stmt_ejercicios->fetch(PDO::FETCH_ASSOC)) {
            $ejercicios[] = $row;
        }

        // Inicializamos el array de dieta
            $dieta = array();

        // Verificamos si el array $id_dieta no está vacío y si algún elemento es mayor que 0
        if (!empty($id_dieta) && max($id_dieta) > 0) {
            // Si hay algún valor mayor que 0, recuperamos los datos de la dieta
            $sql_dieta = "SELECT * FROM dieta WHERE id IN (".implode(",", $id_dieta).")";
            $stmt_dieta = $conexion->query($sql_dieta);
            while ($row = $stmt_dieta->fetch(PDO::FETCH_ASSOC)) {
                $dieta[] = $row;
            }
        } else {
            // Si el array está vacío todos los valores serán 0, llenamos el array con ceros
            $id_dieta = array_fill(0, count($id_dieta), 0);
        }

        // Guardamos los ejercicios y la dieta en un array y lo devolvemos
        $rutina['ejercicios'] = $ejercicios;
        $rutina['dieta'] = $dieta;
        return $rutina;
    }

    // Creamos una función el cuál nos devuelva un mensaje distinto, depende del objetivo que tenga el usuario
    function obtenerMensajeObjetivo($conexion, $id_usuario) {
        try {
            $sql_objetivo = "SELECT objetivo, pesas FROM rutina WHERE id_usuario = :id_usuario";
            $stmt_objetivo = $conexion->prepare($sql_objetivo);
            $stmt_objetivo->bindValue(":id_usuario", $id_usuario, PDO::PARAM_INT);
            $stmt_objetivo->execute();
        
            // Obtener el objetivo y la indicación de pesas del usuario
            $row = $stmt_objetivo->fetch(PDO::FETCH_ASSOC);
            $objetivo_usuario = $row['objetivo'];
            $pesas = $row['pesas'];
    
            // Definir el mensaje base según el objetivo
            switch ($objetivo_usuario) {
                case "perder_peso":
                    if ($pesas == 1) {
                        $mensaje = "Para perder peso, usa un peso moderado que te permita hacer de 12 a 15 repeticiones por serie, completando 3-4 series por ejercicio. 
                                    <br><strong>¡Recuerda mantener una buena técnica y desafiarte a ti mismo en cada serie!</strong><br><br>";
                    } else {
                        $mensaje = "Para perder peso, enfócate en ejercicios cardiovasculares y de resistencia muscular sin necesidad de pesas.
                                    <br><strong>¡Recuerda mantener un ritmo constante y desafiarte a ti mismo gradualmente!</strong><br><br>";
                    }
                    break;
                case "ganar_musculo":
                    if ($pesas == 1) {
                        $mensaje = "Para ganar músculo, deberás realizar de 8 a 12 repeticiones por serie con un peso que te desafíe al final de cada serie. Realiza de 3 a 4 series por ejercicio para obtener un volumen de trabajo efectivo. 
                                    <br><strong>¡Recuerda mantener una buena técnica y enfócate en la progresión de los pesos!</strong><br><br>";
                    } else {
                        $mensaje = "Para ganar músculo, enfócate en ejercicios de resistencia muscular que desafíen tu capacidad sin necesidad de pesas.
                                    <br><strong>¡Recuerda mantener una buena técnica y aumentar gradualmente la intensidad de tus ejercicios!</strong><br><br>";
                    }
                    break;
                case "aumentar_resistencia":
                    if ($pesas == 1) {
                        $mensaje = "Realiza repeticiones más altas (15-20) con un peso más ligero para aumentar la resistencia muscular y cardiovascular. 
                                    <br><strong>¡Recuerda mantener un ritmo constante y desafiarte a ti mismo gradualmente!</strong><br><br>";
                    } else {
                        $mensaje = "Realiza ejercicios que mejoren tu resistencia cardiovascular y muscular sin necesidad de pesas.
                                    <br><strong>¡Recuerda mantener un ritmo constante y desafiarte a ti mismo en cada sesión de entrenamiento!</strong><br><br>";
                    }
                    break;
                default:
                    $mensaje = "Objetivo no especificado";
                    break;
            }
    
            return $mensaje;
        } catch (PDOException $e) {
            // Manejo de errores si ocurre alguna excepción
            echo "Error al obtener el mensaje de objetivo: " . $e->getMessage();
            return false;
        }
    }    

    // Actualizamos la contraseña de nuestra base de datos
    function rutina0($conexion, $id_usuario){
        // Creamos nuestro SQL y lo preparamos para que sólo lo tenga que ejecutar el sql
        $sql = "DELETE FROM rutina WHERE id_usuario = :id_usuario";
        $stmt = $conexion->prepare($sql);
        $stmt->bindValue(":id_usuario", $id_usuario, PDO::PARAM_INT);
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    // Función para crear una nueva dieta y actualizar la tabla rutina con los nuevos IDs de dieta
    function crearOtraDieta($conexion, $id_usuario) {
        try {
            // Obtener el objetivo del usuario desde la tabla rutina
            $sql_objetivo = "SELECT objetivo FROM rutina WHERE id_usuario = :id_usuario";
            $stmt_objetivo = $conexion->prepare($sql_objetivo);
            $stmt_objetivo->bindValue(":id_usuario", $id_usuario, PDO::PARAM_INT);
            $stmt_objetivo->execute();
            $objetivo = $stmt_objetivo->fetch(PDO::FETCH_COLUMN);

            $resultado = array();
            // Seleccionar IDs de dieta donde el objetivo coincida
            $sql = "SELECT id FROM dieta WHERE objetivo = :objetivo ORDER BY RAND()";
            $stmt = $conexion->prepare($sql);
            $stmt->bindValue(":objetivo", $objetivo, PDO::PARAM_STR);
            $stmt->execute();
            $resultado = $stmt->fetchAll(PDO::FETCH_COLUMN);

            // Tomar solo los primeros 7 resultados
            $id_dieta = array_slice($resultado, 0, 7);

            // Actualizar la tabla rutina con los nuevos IDs de dieta
            $sql_update = "UPDATE rutina SET id_dieta = :id_dieta WHERE id_usuario = :id_usuario";
            $stmt_update = $conexion->prepare($sql_update);
            $stmt_update->bindValue(":id_dieta", implode(",", $id_dieta), PDO::PARAM_STR);
            $stmt_update->bindValue(":id_usuario", $id_usuario, PDO::PARAM_INT);
            $stmt_update->execute();

            return true; // Éxito al actualizar la rutina con la nueva dieta
        } catch (PDOException $e) {
            // Manejo de errores si ocurre alguna excepción
            echo "Error al crear otra dieta y actualizar rutina: " . $e->getMessage();
            return false;
        }
    }

?>