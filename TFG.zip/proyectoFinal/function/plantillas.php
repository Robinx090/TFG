<!-- Creamos la función para que podamos poner las tarjetas con su imagen y su pequeña descripción sin tener que repetir código-->
<?php function loadCard($ruta_img, $alt, $title, $text, $rutaPag){ ?>
    <!-- Colocamos el HTML necesario una vez y colocamos las variables para poder reutilizar el mismo código -->
    <div class="col-lg-4 col-md-6 col-sm-12 mb-4 d-flex align-items-center">
        <a href="<?=$rutaPag?>">
            <div class="card">
                <img src="<?= $ruta_img?>" class="card-img-top img-fluid" alt="<?= $alt ?>" style="max-height: 400px;">
                <div class="card-body">
                    <h5 class="card-title"><?= $title ?></h5>
                    <p class="card-text"> <?= $text ?> </p>
                </div>
            </div>
        </a>
    </div>
<?php } ?>
                
<!-- Creamos la función la cuál cargará la información que se encuentra dentro de las tarjetas --> 
<?php
    function info_Card($imagesArray, $title, $description, $evaluacion, $tips) { ?>
        <div class="container">
            <h1 class="text-center encabezado"><?= $title ?></h1>
            <p><?= $description ?></p>

            <!-- Contenedor de IMAGENES -->
            <div class="containIMG text-center mt-5 mb-5">
                <!-- Recorremos sólo las 2 primeras imagenes -->
                <?php foreach (array_slice($imagesArray, 0, 2) as $image) { ?>
                    <!-- Comprobamos de que haya alguna imagen -->
                    <?php if(isset($image['src']) && !empty($image['src'])) { ?>
                        <img src='<?= $image['src'] ?>' class="img-fluid p-2" style="max-height: 500px;" alt='<?= $image['alt'] ?>'>
                    <?php } ?>
                <?php } ?>
            </div>

            <!-- Pondremos las ventajas o desventajas que tendrá hacerlo -->
            <h3 class="encabezado mt-3">Evaluación</h3>
            <p class="card-text"><?= $evaluacion ?></p>
            <div class="containIMG text-center mt-5 mb-5">
                <!-- Recorremos las otras 2 imagenes restantes -->
                <?php foreach (array_slice($imagesArray, 2) as $image) { ?>
                    <!-- Comprobamos de que haya alguna imagen -->
                    <?php if(isset($image['src']) && !empty($image['src'])) { ?>
                        <img src='<?= $image['src'] ?>' class="img-fluid p-2" alt='<?= $image['alt'] ?>'>
                    <?php } ?>
                <?php } ?>
            </div>

            <h3 class="encabezado mt-3">Consejos</h3>
            <!-- Compartiremos tips y respaldadas por las investigaciones -->
            <p class="card-text"><?= $tips ?></p>
        </div>
<?php } ?>